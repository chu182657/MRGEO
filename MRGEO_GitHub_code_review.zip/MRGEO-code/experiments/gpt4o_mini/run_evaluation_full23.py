"""
run_evaluation_full23.py
========================
ChatAnywhere 版本 23 指标评测脚本。

读取已有 generation_results.jsonl，不重新生成文本。
默认输入：outputs/generations/generation_results.jsonl
默认输出：outputs/scores/evaluation_results_full23_chatanywhere_SAFE.csv

运行：
    python run_evaluation_full23.py --max-samples 200 --resume
"""

import argparse
import csv
import json
import logging
import time
from pathlib import Path
from collections import Counter
from typing import Any, Dict, List, Optional, Set, Tuple

from config import OUTPUT_DIR
try:
    from config import REQUEST_INTERVAL
except Exception:
    REQUEST_INTERVAL = 0.5

try:
    from config import METHOD_LIST
except Exception:
    METHOD_LIST = [
        "uniqueness", "simplification", "authority", "fluency",
        "terminology", "reputation", "citation", "statistics",
        "autogeo", "intent_geo", "multimodal", "multi_agent",
        "rag_based", "m2geo",
    ]

try:
    from data_loader import load_samples
except Exception:
    load_samples = None

from chatanywhere_client import ChatAnywhereClient
from judge_full import JUDGE_METRICS, judge_response


VISIBILITY_METRICS = ["citation_prominence", "answer_dominance", "visibility_overall"]
SUBJECTIVE_METRICS = [
    "relevance", "influence", "uniqueness", "diversity",
    "click_likelihood", "subjective_position", "subjective_volume",
]
FAITHFULNESS_METRICS = [
    "attribution_accuracy", "faithfulness", "evidence_precision", "evidence_recall",
    "key_point_coverage", "semantic_contribution", "key_point_recall",
]
UTILITY_METRICS = ["clarity", "insight", "coherence", "structure_quality", "readability"]
SUMMARY_METRICS = ["objective_score", "subjective_score", "faithfulness_score", "utility_score", "overall_score"]
FIELDNAMES = ["sample_id", "method", "query"] + JUDGE_METRICS + SUMMARY_METRICS + ["judge_explanation", "judge_error"]

METHOD_SET = set(METHOD_LIST)


def setup_logger() -> logging.Logger:
    logger = logging.getLogger("run_evaluation_full23")
    if logger.handlers:
        return logger
    logger.setLevel(logging.INFO)
    fmt = logging.Formatter("%(asctime)s | %(levelname)s | %(message)s")
    sh = logging.StreamHandler()
    sh.setFormatter(fmt)
    logger.addHandler(sh)
    log_dir = OUTPUT_DIR / "logs"
    log_dir.mkdir(parents=True, exist_ok=True)
    fh = logging.FileHandler(log_dir / "evaluation_full23_chatanywhere.log", encoding="utf-8")
    fh.setFormatter(fmt)
    logger.addHandler(fh)
    return logger


def _first_nonempty(item: Dict[str, Any], keys: List[str]) -> str:
    for key in keys:
        val = item.get(key)
        if val is not None and str(val).strip():
            return str(val).strip()
    return ""


def _extract_text(value: Any) -> str:
    """
    从字符串、dict、list 中尽量提取文本。
    """
    if value is None:
        return ""

    if isinstance(value, str):
        return value.strip()

    if isinstance(value, dict):
        # 常见文本字段
        for key in [
            "generated_answer", "generated_response", "generated_text",
            "generation", "response", "answer", "answer_text",
            "content", "text", "output", "result", "method_output",
            "optimized_text", "rewritten_text", "rewrite", "completion",
            "final_answer",
        ]:
            val = value.get(key)
            if val is not None and str(val).strip():
                return str(val).strip()

        # OpenAI-like 结构
        choices = value.get("choices")
        if isinstance(choices, list) and choices:
            msg = choices[0].get("message", {})
            content = msg.get("content")
            if content:
                return str(content).strip()

        # 兜底：如果只有一个字符串值，就取它
        str_vals = [str(v).strip() for v in value.values() if isinstance(v, str) and str(v).strip()]
        if len(str_vals) == 1:
            return str_vals[0]

        return ""

    if isinstance(value, list):
        parts = [_extract_text(x) for x in value]
        parts = [p for p in parts if p]
        return "\n".join(parts).strip()

    return str(value).strip()


def _normalize_record(item: Dict[str, Any], fallback_method: str = "") -> Dict[str, Any]:
    sample_id = _first_nonempty(item, ["sample_id", "sampleId", "id", "sample", "sample_index", "index", "idx"])
    method = _first_nonempty(item, ["method", "method_name", "methodName", "strategy", "strategy_name", "geo_method", "approach", "optimizer"]) or fallback_method
    query = _first_nonempty(item, ["query", "question", "prompt_query", "user_query", "instruction", "task", "title"])

    response = ""
    for key in [
        "generated_answer", "generated_response", "generated_text",
        "generation", "response", "answer", "answer_text",
        "content", "text", "output", "result", "method_output",
        "optimized_text", "rewritten_text", "rewrite", "completion",
        "final_answer",
    ]:
        if key in item:
            response = _extract_text(item.get(key))
            if response:
                break

    if not response:
        response = _extract_text(item)

    normalized = dict(item)
    normalized["sample_id"] = sample_id
    normalized["method"] = method or "unknown"
    normalized["query"] = query
    normalized["generated_answer"] = response
    return normalized


def _flatten_generation_records(raw_records: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """
    兼容三类生成结果：
    1. 标准：每条记录有 sample_id / method / generated_answer
    2. 嵌套：outputs/responses/answers/generations/results 里按方法名存文本
    3. 顶层：记录顶层直接有 m2geo / citation / multi_agent 等字段
    """
    flattened: List[Dict[str, Any]] = []
    nested_keys = ["outputs", "responses", "answers", "generations", "generation_results", "method_outputs", "results", "data"]

    for item in raw_records:
        if not isinstance(item, dict):
            continue

        sample_id = _first_nonempty(item, ["sample_id", "sampleId", "id", "sample", "sample_index", "index", "idx"])
        query = _first_nonempty(item, ["query", "question", "prompt_query", "user_query", "instruction", "task", "title"])

        expanded = False

        # 情况 A：某个容器字段里是 {method: text}
        for container_key in nested_keys:
            container = item.get(container_key)

            if isinstance(container, dict):
                method_keys = [k for k in container.keys() if str(k) in METHOD_SET]
                if method_keys:
                    for method in method_keys:
                        rec = dict(item)
                        rec.pop(container_key, None)
                        rec["sample_id"] = sample_id
                        rec["query"] = query
                        rec["method"] = method
                        rec["generated_answer"] = _extract_text(container.get(method))
                        flattened.append(rec)
                    expanded = True

            elif isinstance(container, list):
                # 情况 B：results: [{"method": "...", "output": "..."}]
                for sub in container:
                    if isinstance(sub, dict):
                        rec = dict(item)
                        rec.pop(container_key, None)
                        rec.update(sub)
                        rec["sample_id"] = _first_nonempty(rec, ["sample_id", "sampleId", "id", "sample", "sample_index", "index", "idx"]) or sample_id
                        rec["query"] = _first_nonempty(rec, ["query", "question", "prompt_query", "user_query", "instruction", "task", "title"]) or query
                        flattened.append(_normalize_record(rec))
                        expanded = True

        if expanded:
            continue

        # 情况 C：顶层直接有方法名字段
        top_method_keys = [k for k in item.keys() if str(k) in METHOD_SET]
        if top_method_keys:
            for method in top_method_keys:
                rec = dict(item)
                rec["sample_id"] = sample_id
                rec["query"] = query
                rec["method"] = method
                rec["generated_answer"] = _extract_text(item.get(method))
                flattened.append(rec)
            continue

        # 标准单条
        flattened.append(_normalize_record(item))

    return flattened


def load_jsonl(path: Path) -> List[Dict[str, Any]]:
    """
    读取生成结果文件，并自动展开/规范字段。
    兼容 JSONL、JSON数组、{"results": [...]}、{"data": [...]}、{"records": [...]}。
    """
    if not path.exists():
        raise FileNotFoundError(f"找不到生成结果文件：{path}")

    raw_text = path.read_text(encoding="utf-8").strip()
    if not raw_text:
        raise ValueError(f"生成结果文件为空：{path}")

    raw_records: List[Dict[str, Any]] = []

    # 整体 JSON
    if raw_text[0] in "[{":
        try:
            data = json.loads(raw_text)
            if isinstance(data, list):
                raw_records = [x for x in data if isinstance(x, dict)]
            elif isinstance(data, dict):
                for key in ["results", "data", "records", "items", "generations"]:
                    value = data.get(key)
                    if isinstance(value, list):
                        raw_records = [x for x in value if isinstance(x, dict)]
                        break
                if not raw_records:
                    raw_records = [data]
        except json.JSONDecodeError:
            raw_records = []

    # JSONL fallback
    if not raw_records:
        with path.open("r", encoding="utf-8") as f:
            for line_no, line in enumerate(f, start=1):
                line = line.strip()
                if not line or line in ("[", "]"):
                    continue
                if line.endswith(","):
                    line = line[:-1].strip()
                try:
                    item = json.loads(line)
                except json.JSONDecodeError as e:
                    raise ValueError(f"第 {line_no} 行不是合法 JSON：{line[:180]}") from e
                if isinstance(item, dict):
                    raw_records.append(item)
                elif isinstance(item, list):
                    raw_records.extend([x for x in item if isinstance(x, dict)])

    if not raw_records:
        raise ValueError(f"没有读取到有效生成记录：{path}")

    return _flatten_generation_records(raw_records)


def get_response(item: Dict[str, Any]) -> str:
    # 优先读已经规范化后的 generated_answer
    val = item.get("generated_answer")
    if val is not None and str(val).strip():
        return str(val).strip()

    # 再兼容其他字段
    for key in [
        "generated_response", "generated_text", "generation",
        "response", "answer", "answer_text", "content", "text",
        "output", "result", "method_output", "optimized_text",
        "rewritten_text", "rewrite", "completion", "final_answer",
    ]:
        val = item.get(key)
        if val is not None and str(val).strip():
            return str(val).strip()

    return ""


def format_documents(docs: Any) -> str:
    if not docs:
        return ""
    if isinstance(docs, str):
        return docs.strip()
    if isinstance(docs, list):
        parts = []
        for i, d in enumerate(docs, 1):
            if isinstance(d, dict):
                text = d.get("text") or d.get("content") or ""
            else:
                text = str(d)
            text = str(text).strip()
            if text:
                parts.append(f"[Doc {i}] {text}")
        return "\n\n".join(parts)
    if isinstance(docs, dict):
        return str(docs.get("text") or docs.get("content") or docs).strip()
    return str(docs).strip()


def build_sample_map() -> Dict[str, Dict[str, Any]]:
    if load_samples is None:
        return {}
    try:
        samples = load_samples()
    except Exception:
        return {}
    mp = {}
    for idx, s in enumerate(samples):
        sid = str(s.get("sample_id", idx + 1))
        mp[sid] = s
    return mp


def get_source_text(item: Dict[str, Any], sample_map: Dict[str, Dict[str, Any]]) -> str:
    for key in ["source_text", "original_text", "raw_text", "document_text", "documents"]:
        if key in item and item.get(key):
            return format_documents(item.get(key))
    sid = str(item.get("sample_id", ""))
    sample = sample_map.get(sid, {})
    if sample:
        for key in ["source_text", "original_text", "raw_text", "document_text", "documents"]:
            if key in sample and sample.get(key):
                return format_documents(sample.get(key))
    return ""


def keep_first_n_sample_ids(records: List[Dict[str, Any]], n: int) -> List[Dict[str, Any]]:
    selected = []
    seen = set()
    for item in records:
        sid = str(item.get("sample_id", "")).strip()
        if not sid:
            continue
        if sid not in seen:
            seen.add(sid)
            selected.append(sid)
        if len(selected) >= n:
            break
    allowed = set(selected)
    return [r for r in records if str(r.get("sample_id", "")).strip() in allowed]


def load_existing_keys(output_file: Path) -> Set[Tuple[str, str]]:
    done = set()
    if not output_file.exists():
        return done
    with output_file.open("r", encoding="utf-8-sig") as f:
        reader = csv.DictReader(f)
        for row in reader:
            sid = str(row.get("sample_id", ""))
            method = str(row.get("method", ""))
            err = str(row.get("judge_error", ""))
            overall = str(row.get("overall_score", ""))
            if sid and method and overall and not err:
                done.add((sid, method))
    return done


def mean_safe(values: List[Any]) -> float:
    nums = []
    for v in values:
        try:
            nums.append(float(v))
        except Exception:
            pass
    return round(sum(nums) / len(nums), 4) if nums else 0.0


def add_summary_scores(row: Dict[str, Any]) -> None:
    objective_score = mean_safe([row.get(m, 0) for m in VISIBILITY_METRICS])
    subjective_score = mean_safe([row.get(m, 0) for m in SUBJECTIVE_METRICS])
    contradiction = float(row.get("key_point_contradiction", 0) or 0)
    key_point_consistency = max(0.0, min(5.0, 5.0 - contradiction))
    faithfulness_score = mean_safe([row.get(m, 0) for m in FAITHFULNESS_METRICS] + [key_point_consistency])
    utility_score = mean_safe([row.get(m, 0) for m in UTILITY_METRICS])
    overall_score = round(0.30 * objective_score + 0.30 * subjective_score + 0.25 * faithfulness_score + 0.15 * utility_score, 4)
    row["objective_score"] = objective_score
    row["subjective_score"] = subjective_score
    row["faithfulness_score"] = faithfulness_score
    row["utility_score"] = utility_score
    row["overall_score"] = overall_score


def evaluate_one(item: Dict[str, Any], sample_map: Dict[str, Dict[str, Any]], client: Optional[ChatAnywhereClient], enable_judge: bool) -> Dict[str, Any]:
    sample_id = str(item.get("sample_id", ""))
    method = str(item.get("method", "unknown"))
    query = str(item.get("query", ""))
    response = get_response(item)
    source_text = get_source_text(item, sample_map)

    row = {"sample_id": sample_id, "method": method, "query": query}
    for metric in JUDGE_METRICS:
        row[metric] = 0.0
    row["judge_explanation"] = ""
    row["judge_error"] = ""

    if enable_judge:
        result = judge_response(query=query, response=response, source_text=source_text, method=method, client=client)
        for metric in JUDGE_METRICS:
            row[metric] = result.get(metric, 0.0)
        row["judge_explanation"] = result.get("explanation", "")
        row["judge_error"] = result.get("error", "")

    add_summary_scores(row)
    return row


def save_rows(rows: List[Dict[str, Any]], output_file: Path) -> None:
    output_file.parent.mkdir(parents=True, exist_ok=True)
    with output_file.open("w", encoding="utf-8-sig", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=FIELDNAMES)
        writer.writeheader()
        writer.writerows(rows)


def main():
    parser = argparse.ArgumentParser(description="ChatAnywhere GEO 23指标评测脚本")
    parser.add_argument("--input", type=str, default=str(OUTPUT_DIR / "generations" / "generation_results.jsonl"))
    parser.add_argument("--output", type=str, default=str(OUTPUT_DIR / "scores" / "evaluation_results_full23_chatanywhere_fixed.csv"))
    parser.add_argument("--max-samples", type=int, default=200)
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--no-judge", action="store_true")
    args = parser.parse_args()

    logger = setup_logger()
    input_file = Path(args.input)
    output_file = Path(args.output)

    logger.info("=" * 70)
    logger.info("ChatAnywhere GEO 23指标评测开始")
    logger.info("读取生成结果：%s", input_file)

    records = load_jsonl(input_file)
    logger.info("原始记录数/展开后记录数：%s", len(records))
    if records:
        first = records[0]
        logger.info("第一条记录 keys：%s", list(first.keys()))
        logger.info(
            "第一条预览：sample_id=%s method=%s query_len=%s response_len=%s",
            first.get("sample_id", ""),
            first.get("method", ""),
            len(str(first.get("query", "") or "")),
            len(get_response(first)),
        )
        method_counter = Counter(str(r.get("method", "unknown")) for r in records)
        logger.info("方法分布 Top20：%s", method_counter.most_common(20))
        empty_count = sum(1 for r in records if not get_response(r))
        logger.info("空 response 记录数：%s / %s", empty_count, len(records))

        # 硬性保护：如果输入不是“已生成文章结果”，立刻停止，不再写空评分 CSV。
        # 正常生成结果应包含 method 和 generated_answer/response，且 method 不应全是 unknown。
        unknown_count = method_counter.get("unknown", 0) + method_counter.get("", 0)
        if empty_count > 0 or unknown_count == len(records):
            raise RuntimeError(
                "\n❌ 输入文件不是有效的生成结果，已停止，避免生成全空评分表。\n"
                f"读取记录数: {len(records)}\n"
                f"空 response 记录数: {empty_count}\n"
                f"unknown method 记录数: {unknown_count}\n"
                f"第一条 keys: {list(first.keys())}\n"
                "请检查 --input 是否指向真正的生成文章文件。正确文件应有字段: "
                "sample_id, method, query, generated_answer。\n"
                "正常 200 样本 × 14 方法应约为 2800 条记录。"
            )

    records = keep_first_n_sample_ids(records, args.max_samples)
    sample_ids = sorted({str(r.get("sample_id", "")) for r in records})
    methods = sorted({str(r.get("method", "")) for r in records})
    logger.info("保留前 %s 个 sample_id 后，记录数：%s", args.max_samples, len(records))
    logger.info("样本数：%s，方法数：%s", len(sample_ids), len(methods))
    logger.info("方法列表：%s", ", ".join(methods))

    sample_map = build_sample_map()
    logger.info("原始样本映射数：%s", len(sample_map))

    enable_judge = not args.no_judge
    logger.info("ENABLE_JUDGE=%s", enable_judge)

    done_keys = load_existing_keys(output_file) if args.resume else set()
    if args.resume:
        logger.info("断点续跑：已有完成记录 %s 条", len(done_keys))

    rows = []
    if args.resume and output_file.exists():
        with output_file.open("r", encoding="utf-8-sig") as f:
            rows.extend(list(csv.DictReader(f)))

    client = ChatAnywhereClient() if enable_judge else None
    total = len(records)
    skipped = 0
    failed = 0

    for idx, item in enumerate(records, start=1):
        sample_id = str(item.get("sample_id", ""))
        method = str(item.get("method", "unknown"))
        key = (sample_id, method)

        if args.resume and key in done_keys:
            skipped += 1
            continue

        try:
            row = evaluate_one(item, sample_map, client, enable_judge)
            rows.append(row)
        except Exception as e:
            failed += 1
            logger.exception("评测失败 sample_id=%s method=%s error=%s", sample_id, method, e)
            row = {"sample_id": sample_id, "method": method, "query": str(item.get("query", ""))}
            for metric in JUDGE_METRICS:
                row[metric] = 0.0
            for metric in SUMMARY_METRICS:
                row[metric] = 0.0
            row["judge_explanation"] = ""
            row["judge_error"] = str(e)
            rows.append(row)

        save_rows(rows, output_file)

        if idx % 20 == 0 or idx == total:
            logger.info("进度：%s/%s，跳过=%s，失败=%s，输出=%s", idx, total, skipped, failed, output_file)

        if enable_judge:
            time.sleep(float(REQUEST_INTERVAL))

    logger.info("评测完成：输出 %s 条记录到 %s", len(rows), output_file)
    print(f"\n✅ 23指标评测完成：{output_file}")
    print(f"   记录数：{len(rows)} | 跳过：{skipped} | 失败：{failed}")


if __name__ == "__main__":
    main()
