"""
run_generation.py
=================
333 文件夹专用：ChatAnywhere / GPT-4o-mini 批量生成脚本。

功能：
- 读取 data/samples.json；
- 对前 200 个样本分别运行 14 种 GEO 方法；
- 调用 ChatAnywhere OpenAI-compatible API；
- 保存为标准 JSONL，每一行包含：
    sample_id
    method
    query
    generated_answer
    total_docs

重要：
- 默认输出到 outputs/generations/generation_results_chatanywhere.jsonl
- 不会污染你之前那个可能有问题的 generation_results.jsonl
- 后续评测时请用：
    python run_evaluation_full23.py --max-samples 200 --resume --input outputs/generations/generation_results_chatanywhere.jsonl --output outputs/scores/evaluation_results_full23_chatanywhere_fixed.csv
"""

import argparse
import json
import logging
import time
from pathlib import Path
from typing import Dict, Set, Tuple, List, Any

from config import METHOD_LIST, OUTPUT_DIR
try:
    from config import REQUEST_INTERVAL
except Exception:
    REQUEST_INTERVAL = 0.5

from data_loader import load_samples
from methods import build_prompt
from chatanywhere_client import ChatAnywhereClient


def setup_logger() -> logging.Logger:
    """初始化日志：控制台 + 文件。"""
    logger = logging.getLogger("run_generation")
    if logger.handlers:
        return logger

    logger.setLevel(logging.INFO)
    formatter = logging.Formatter("%(asctime)s | %(levelname)s | %(message)s")

    stream_handler = logging.StreamHandler()
    stream_handler.setFormatter(formatter)
    logger.addHandler(stream_handler)

    log_dir = OUTPUT_DIR / "logs"
    log_dir.mkdir(parents=True, exist_ok=True)
    file_handler = logging.FileHandler(
        log_dir / "generation_chatanywhere.log",
        encoding="utf-8",
    )
    file_handler.setFormatter(formatter)
    logger.addHandler(file_handler)

    return logger


def _load_json_or_jsonl(path: Path) -> List[Dict[str, Any]]:
    """
    读取已有生成结果，兼容 JSONL 和 JSON 数组。
    只用于断点续跑读取 key。
    """
    if not path.exists():
        return []

    text = path.read_text(encoding="utf-8").strip()
    if not text:
        return []

    # JSON 数组 / JSON 对象
    if text[0] in "[{":
        try:
            data = json.loads(text)
            if isinstance(data, list):
                return [x for x in data if isinstance(x, dict)]
            if isinstance(data, dict):
                for key in ["results", "data", "records", "items"]:
                    val = data.get(key)
                    if isinstance(val, list):
                        return [x for x in val if isinstance(x, dict)]
                return [data]
        except json.JSONDecodeError:
            pass

    # JSONL
    rows = []
    with path.open("r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line or line in ("[", "]"):
                continue
            if line.endswith(","):
                line = line[:-1].strip()
            try:
                item = json.loads(line)
                if isinstance(item, dict):
                    rows.append(item)
            except Exception:
                continue

    return rows


def load_existing_keys(output_file: Path) -> Set[Tuple[str, str]]:
    """
    读取已有生成结果，返回已完成的 (sample_id, method)。
    只把 sample_id 和 method 都非空的记录视为有效完成，避免旧坏文件污染断点续跑。
    """
    done: Set[Tuple[str, str]] = set()

    for record in _load_json_or_jsonl(output_file):
        sample_id = str(record.get("sample_id", "")).strip()
        method = str(record.get("method", "")).strip()
        answer = str(record.get("generated_answer", "") or record.get("response", "") or record.get("answer", "")).strip()

        if sample_id and method and answer:
            done.add((sample_id, method))

    return done


def main():
    parser = argparse.ArgumentParser(description="ChatAnywhere / GPT-4o-mini GEO 批量生成脚本")
    parser.add_argument(
        "--test",
        action="store_true",
        help="测试模式：只处理前5条样本，只跑 statistics 和 m2geo",
    )
    parser.add_argument(
        "--max-samples",
        type=int,
        default=200,
        help="正式运行时处理前 N 条样本，默认 200",
    )
    parser.add_argument(
        "--output",
        type=str,
        default=str(OUTPUT_DIR / "generations" / "generation_results_chatanywhere.jsonl"),
        help="生成结果输出 JSONL 文件。默认不覆盖旧 generation_results.jsonl",
    )
    parser.add_argument(
        "--overwrite",
        action="store_true",
        help="如果指定，则删除旧输出文件并重新生成",
    )
    args = parser.parse_args()

    logger = setup_logger()

    # 读取样本
    logger.info("正在加载样本数据...")
    samples = load_samples()
    logger.info("共加载 %s 条样本", len(samples))

    # 方法列表
    methods = list(METHOD_LIST)

    if args.test:
        samples = samples[:5]
        methods = ["statistics", "m2geo"]
        logger.info("【测试模式】只处理前5条样本，方法：statistics, m2geo")
    else:
        samples = samples[: args.max_samples]
        logger.info("限制为前 %s 条样本，共 %s 条", args.max_samples, len(samples))

    # 输出文件
    output_file = Path(args.output)
    output_file.parent.mkdir(parents=True, exist_ok=True)

    if args.overwrite and output_file.exists():
        output_file.unlink()
        logger.info("已删除旧输出文件：%s", output_file)

    # 断点续跑
    done_keys = load_existing_keys(output_file)
    logger.info("已有 %s 条有效完成记录，将跳过这些任务", len(done_keys))

    # 初始化客户端
    client = ChatAnywhereClient()

    total = len(samples) * len(methods)
    completed = 0
    skipped = 0
    failed = 0

    logger.info(
        "开始生成，共 %s 个任务（%s 条样本 × %s 种方法）",
        total,
        len(samples),
        len(methods),
    )
    logger.info("方法列表：%s", ", ".join(methods))
    logger.info("输出文件：%s", output_file)

    with output_file.open("a", encoding="utf-8") as f:
        for sample in samples:
            sample_id = str(sample.get("sample_id", "")).strip()
            query = str(sample.get("query", "")).strip()

            for method in methods:
                key = (sample_id, method)

                if key in done_keys:
                    skipped += 1
                    continue

                try:
                    prompt = build_prompt(method, sample)
                    result = client.send_request(prompt)

                    if not result.get("success"):
                        failed += 1
                        logger.error(
                            "API调用失败 sample_id=%s method=%s error=%s",
                            sample_id,
                            method,
                            result.get("error", "未知错误"),
                        )
                        continue

                    answer = str(result.get("text", "") or "").strip()

                    if not answer:
                        failed += 1
                        logger.error("空回答 sample_id=%s method=%s", sample_id, method)
                        continue

                    record = {
                        "sample_id": sample_id,
                        "method": method,
                        "query": query,
                        "generated_answer": answer,
                        "total_docs": len(sample.get("documents", [])),
                    }

                    f.write(json.dumps(record, ensure_ascii=False) + "\n")
                    f.flush()

                    done_keys.add(key)
                    completed += 1

                    if completed % 50 == 0:
                        logger.info(
                            "进度：%s/%s（本次完成%s 跳过%s 失败%s）",
                            completed + skipped,
                            total,
                            completed,
                            skipped,
                            failed,
                        )

                except Exception as e:
                    failed += 1
                    logger.exception(
                        "生成失败 sample_id=%s method=%s error=%s",
                        sample_id,
                        method,
                        e,
                    )

                finally:
                    time.sleep(float(REQUEST_INTERVAL))

    logger.info(
        "生成完成！本次完成%s条，跳过%s条，失败%s条",
        completed,
        skipped,
        failed,
    )
    logger.info("结果保存在：%s", output_file)

    print(f"\n✅ 生成完成！结果保存在：{output_file}")
    print(f"   本次完成：{completed} | 跳过：{skipped} | 失败：{failed}")
    print("   后续评测命令：")
    print(
        f"   python run_evaluation_full23.py --max-samples {args.max_samples} --resume "
        f"--input {output_file} "
        f"--output outputs/scores/evaluation_results_full23_chatanywhere_fixed.csv"
    )


if __name__ == "__main__":
    main()
