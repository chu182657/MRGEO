import logging
import time
from typing import Any, Dict, Optional

import requests

from config import API_KEY, MAX_RETRIES, MODEL_NAME, OUTPUT_DIR

DEEPSEEK_CHAT_URL = "https://api.deepseek.com/v1/chat/completions"


class DeepSeekClient:
    """
    DeepSeek API 客户端封装（OpenAI 兼容 chat/completions）。

    特性：
    - send_request(prompt) 统一调用入口
    - 自动重试
    - 超时处理
    - 基本日志记录
    - 统一返回格式，不抛出致命异常给上层
    """

    def __init__(
        self,
        api_key: Optional[str] = None,
        model_name: Optional[str] = None,
        max_retries: Optional[int] = None,
        timeout: float = 30.0,
    ) -> None:
        self.api_key = api_key or API_KEY
        self.model_name = model_name or MODEL_NAME
        self.max_retries = max_retries if max_retries is not None else MAX_RETRIES
        self.timeout = timeout
        self.url = DEEPSEEK_CHAT_URL
        self.logger = self._build_logger()

    def _build_logger(self) -> logging.Logger:
        """
        构建基础 logger（控制台 + 文件）。
        """
        logger = logging.getLogger("deepseek_client")
        if logger.handlers:
            return logger

        logger.setLevel(logging.INFO)
        formatter = logging.Formatter(
            "%(asctime)s | %(levelname)s | %(name)s | %(message)s"
        )

        stream_handler = logging.StreamHandler()
        stream_handler.setFormatter(formatter)
        logger.addHandler(stream_handler)

        try:
            log_dir = OUTPUT_DIR / "logs"
            log_dir.mkdir(parents=True, exist_ok=True)
            file_handler = logging.FileHandler(log_dir / "deepseek_client.log", encoding="utf-8")
            file_handler.setFormatter(formatter)
            logger.addHandler(file_handler)
        except Exception:
            # 日志文件写入失败时，不影响主流程
            pass

        return logger

    @staticmethod
    def _ok(text: str) -> Dict[str, Any]:
        return {"success": True, "text": text, "error": None}

    @staticmethod
    def _fail(error_msg: str) -> Dict[str, Any]:
        return {"success": False, "text": "", "error": error_msg}

    def send_request(self, prompt: str) -> Dict[str, Any]:
        """
        发送单次请求（内含重试逻辑）。

        返回统一格式：
        {
          "success": true/false,
          "text": "...",
          "error": "..."
        }
        """
        if not self.api_key or self.api_key == "你的_deepseek_api_key":
            error_msg = "API key 未配置，请在 config.py 中设置 API_KEY。"
            self.logger.error(error_msg)
            return self._fail(error_msg)

        headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {self.api_key}",
        }
        payload: Dict[str, Any] = {
            "model": self.model_name,
            "messages": [{"role": "user", "content": prompt}],
        }

        last_error = "未知错误"
        for attempt in range(1, self.max_retries + 1):
            try:
                self.logger.info("发送 DeepSeek 请求，attempt=%s/%s", attempt, self.max_retries)
                response = requests.post(
                    self.url,
                    headers=headers,
                    json=payload,
                    timeout=self.timeout,
                )
                response.raise_for_status()
                result = response.json()

                choices = result.get("choices") or []
                text = None
                if choices:
                    msg = choices[0].get("message") or {}
                    text = msg.get("content")
                if not text:
                    last_error = f"响应结构异常或无文本内容: {result}"
                    self.logger.error(last_error)
                else:
                    return self._ok(str(text))

            except requests.exceptions.Timeout:
                last_error = f"请求超时（>{self.timeout}s）"
                self.logger.warning(
                    "DeepSeek 请求超时，attempt=%s/%s", attempt, self.max_retries
                )
            except requests.exceptions.RequestException as exc:
                last_error = f"请求异常: {exc}"
                self.logger.warning(
                    "DeepSeek 请求失败，attempt=%s/%s，error=%s",
                    attempt,
                    self.max_retries,
                    exc,
                )
            except Exception as exc:
                last_error = f"未预期异常: {exc}"
                self.logger.exception(
                    "DeepSeek 未预期异常，attempt=%s/%s", attempt, self.max_retries
                )

            # 失败后短暂退避，再重试
            if attempt < self.max_retries:
                time.sleep(min(2 * attempt, 5))

        self.logger.error("DeepSeek 请求最终失败: %s", last_error)
        return self._fail(last_error)


def call_deepseek(prompt: str) -> str:
    """
    简化封装：
    - 成功返回文本
    - 失败返回空字符串（不抛异常）
    """
    client = DeepSeekClient()
    result = client.send_request(prompt)
    return result["text"] if result["success"] else ""
