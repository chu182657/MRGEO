"""
config.py
=========
GEO 实验全局配置文件。
"""

from pathlib import Path
import os

# ──────────────────────────────────────────────
# 路径配置
# ──────────────────────────────────────────────

# 项目根目录
BASE_DIR = Path(__file__).resolve().parent

# 数据文件路径
DATA_PATH = BASE_DIR / "data" / "samples.json"

# 所有输出目录
OUTPUT_DIR = Path(os.getenv("MRGEO_OUTPUT_DIR", str(BASE_DIR / "outputs")))

# ──────────────────────────────────────────────
# API 配置
# ──────────────────────────────────────────────

API_KEY = os.getenv("API_KEY", "")

# DeepSeek 模型名
MODEL_NAME = "deepseek-chat"

# DeepSeek API 地址
API_BASE_URL = "https://api.deepseek.com/v1/chat/completions"

# ──────────────────────────────────────────────
# 实验方法列表
# ──────────────────────────────────────────────

METHOD_LIST = [
    # Baseline 8种
    "uniqueness",
    "simplification",
    "authority",
    "fluency",
    "terminology",
    "reputation",
    "citation",
    "statistics",
    # Advanced 5种
    "autogeo",
    "intent_geo",
    "multimodal",
    "multi_agent",
    "rag_based",
    # M²GEO
    "m2geo",
]

# ──────────────────────────────────────────────
# 运行参数
# ──────────────────────────────────────────────

MAX_RETRIES = 3
CONCURRENCY = 3
TIMEOUT = 60.0

# ✅ 已开启 LLM 评判
ENABLE_JUDGE = True

REQUEST_INTERVAL = 0.5