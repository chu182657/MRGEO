"""
gemini_client.py
================
Gemini + ChatAnywhere 客户端封装

用途：
1. 通过 ChatAnywhere 的 OpenAI-compatible 接口调用 Gemini
2. 给 run_evaluation_full23.py / judge_full.py 提供统一请求入口
3. 增加 timeout、重试、限速、日志
4. 尽量减少 403、567、JSON 截断、空响应等问题
"""

import logging
import time
from typing import Any, Dict, Optional

import requests

from config import (
    API_KEY,
    API_BASE_URL,
    MODEL_NAME,
    MAX_RETRIES,
    OUTPUT_DIR,
    TIMEOUT,
    REQUEST_INTERVAL,
    MAX_OUTPUT_TOKENS,
    TEMPERATURE,
    USE_RESPONSE_FORMAT_JSON,
)


class GeminiClient:
    """
    Gemini via ChatAnywhere 的 OpenAI-compatible chat/completions 客户端

    返回格式统一为：
    {
        "success": True/False,
        "text": "模型返回文本",
        "error": None 或 错误信息,
        "raw": 原始响应字典
    }
    """

    def __init__(
        self,
        api_key: Optional[str] = None,
        model_name: Optional[str] = None,
        api_base_url: Optional[str] = None,
        max_retries: Optional[int] = None,
        timeout: Optional[float] = None,
    ) -> None:
        self.api_key = api_key or API_KEY
        self.model_name = model_name or MODEL_NAME
        self.api_base_url = api_base_url or API_BASE_URL
        self.max_retries = max_retries if max_retries is not None else MAX_RETRIES
        self.timeout = timeout if timeout is not None else TIMEOUT

        self.url = self._normalize_url(self.api_base_url)
        self.logger = self._build_logger()

        # 用于限速
        self.last_request_time = 0.0

    @staticmethod
    def _normalize_url(url: str) -> str:
        """
        兼容两种写法：
        1. https://api.chatanywhere.tech/v1
        2. https://api.chatanywhere.tech/v1/chat/completions

        最终统一成：
        https://api.chatanywhere.tech/v1/chat/completions
        """
        url = str(url).strip().rstrip("/")

        if url.endswith("/chat/completions"):
            return url

        return url + "/chat/completions"

    def _build_logger(self) -> logging.Logger:
        logger = logging.getLogger("gemini_client")

        if logger.handlers:
            return logger

        logger.setLevel(logging.INFO)

        formatter = logging.Formatter(
            "%(asctime)s | %(levelname)s | %(name)s | %(message)s"
        )

        # 控制台日志
        stream_handler = logging.StreamHandler()
        stream_handler.setFormatter(formatter)
        logger.addHandler(stream_handler)

        # 文件日志
        try:
            log_dir = OUTPUT_DIR / "logs"
            log_dir.mkdir(parents=True, exist_ok=True)

            file_handler = logging.FileHandler(
                log_dir / "gemini_client.log",
                encoding="utf-8",
            )
            file_handler.setFormatter(formatter)
            logger.addHandler(file_handler)
        except Exception:
            pass

        return logger

    def _wait_interval(self) -> None:
        """
        按 REQUEST_INTERVAL 控制请求间隔
        """
        now = time.time()

        if self.last_request_time == 0:
            self.last_request_time = now
            return

        elapsed = now - self.last_request_time
        if elapsed < REQUEST_INTERVAL:
            sleep_time = REQUEST_INTERVAL - elapsed
            self.logger.info("请求间隔不足，等待 %.2f 秒", sleep_time)
            time.sleep(sleep_time)

        self.last_request_time = time.time()

    @staticmethod
    def _extract_text_from_response(result: Dict[str, Any]) -> str:
        """
        从 OpenAI-compatible 的返回中提取文本
        """
        choices = result.get("choices", [])
        if not choices:
            return ""

        first_choice = choices[0] or {}
        message = first_choice.get("message", {}) or {}
        content = message.get("content")

        # 常规：字符串
        if isinstance(content, str):
            return content.strip()

        # 有些接口 content 可能是 list
        if isinstance(content, list):
            parts = []
            for item in content:
                if isinstance(item, dict):
                    if "text" in item:
                        parts.append(str(item["text"]))
                    elif "content" in item:
                        parts.append(str(item["content"]))
                else:
                    parts.append(str(item))
            return "".join(parts).strip()

        # 兜底：某些兼容接口可能给 text
        text = first_choice.get("text")
        if isinstance(text, str):
            return text.strip()

        return ""

    def send_request(self, prompt: str, system_prompt: Optional[str] = None) -> Dict[str, Any]:
        """
        发送请求到 ChatAnywhere 的 Gemini 模型
        """

        if (
            not self.api_key
            or "在这里填" in str(self.api_key)
            or "你的" in str(self.api_key)
            or str(self.api_key).strip() in ["", "REMOVED_API_KEY"]
        ):
            return {
                "success": False,
                "text": "",
                "error": "API_KEY 未正确配置，请先检查 config.py",
                "raw": None,
            }

        headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {self.api_key}",
        }

        messages = []
        if system_prompt:
            messages.append({"role": "system", "content": str(system_prompt)})
        messages.append({"role": "user", "content": str(prompt)})

        payload: Dict[str, Any] = {
            "model": self.model_name,
            "messages": messages,
            "temperature": TEMPERATURE,
            "max_tokens": MAX_OUTPUT_TOKENS,
        }

        # 某些中转站/模型不支持 response_format
        if USE_RESPONSE_FORMAT_JSON:
            payload["response_format"] = {"type": "json_object"}

        last_error = "未知错误"

        for attempt in range(1, self.max_retries + 1):
            try:
                self._wait_interval()

                self.logger.info(
                    "发送 Gemini 请求，model=%s，attempt=%d/%d",
                    self.model_name,
                    attempt,
                    self.max_retries,
                )

                response = requests.post(
                    self.url,
                    headers=headers,
                    json=payload,
                    timeout=self.timeout,
                )

                # 常见限流/服务繁忙
                if response.status_code in [429, 500, 502, 503, 504, 567]:
                    last_error = (
                        f"服务繁忙或限流，status={response.status_code}, "
                        f"body={response.text[:500]}"
                    )
                    self.logger.warning(last_error)

                    if attempt < self.max_retries:
                        sleep_time = min(2 * attempt, 8)
                        self.logger.info("等待 %.2f 秒后重试", sleep_time)
                        time.sleep(sleep_time)
                        continue

                    return {
                        "success": False,
                        "text": "",
                        "error": last_error,
                        "raw": None,
                    }

                # 403 单独处理
                if response.status_code == 403:
                    last_error = (
                        "403 Forbidden：可能是模型无权限、key不可用、余额不足、"
                        f"或触发风控。body={response.text[:500]}"
                    )
                    self.logger.error(last_error)
                    return {
                        "success": False,
                        "text": "",
                        "error": last_error,
                        "raw": None,
                    }

                response.raise_for_status()

                result = response.json()
                text = self._extract_text_from_response(result)

                if not text:
                    last_error = f"响应里没有可提取文本，原始返回：{str(result)[:800]}"
                    self.logger.error(last_error)

                    if attempt < self.max_retries:
                        sleep_time = min(2 * attempt, 8)
                        self.logger.info("等待 %.2f 秒后重试", sleep_time)
                        time.sleep(sleep_time)
                        continue

                    return {
                        "success": False,
                        "text": "",
                        "error": last_error,
                        "raw": result,
                    }

                self.logger.info("Gemini 请求成功，返回长度=%d 字符", len(text))

                return {
                    "success": True,
                    "text": text,
                    "error": None,
                    "raw": result,
                }

            except requests.exceptions.Timeout:
                last_error = f"请求超时（>{self.timeout} 秒）"
                self.logger.warning("Gemini 请求超时，attempt=%d/%d", attempt, self.max_retries)

            except requests.exceptions.ConnectionError as exc:
                last_error = f"网络连接错误：{exc}"
                self.logger.warning(
                    "Gemini 网络连接异常，attempt=%d/%d，error=%s",
                    attempt,
                    self.max_retries,
                    exc,
                )

            except requests.exceptions.RequestException as exc:
                error_body = ""
                try:
                    if exc.response is not None:
                        error_body = f" | body={exc.response.text[:500]}"
                except Exception:
                    pass

                last_error = f"请求异常：{exc}{error_body}"
                self.logger.warning(
                    "Gemini 请求异常，attempt=%d/%d，error=%s",
                    attempt,
                    self.max_retries,
                    last_error,
                )

            except Exception as exc:
                last_error = f"未预期异常：{exc}"
                self.logger.exception(
                    "Gemini 未预期异常，attempt=%d/%d",
                    attempt,
                    self.max_retries,
                )

            if attempt < self.max_retries:
                sleep_time = min(2 * attempt, 8)
                self.logger.info("等待 %.2f 秒后重试", sleep_time)
                time.sleep(sleep_time)

        return {
            "success": False,
            "text": "",
            "error": last_error,
            "raw": None,
        }


# 兼容旧代码：有些脚本可能写的是 from gemini_client import LLMClient
LLMClient = GeminiClient


def call_gemini(prompt: str) -> str:
    """
    简化调用
    成功返回文本，失败返回空字符串
    """
    client = GeminiClient()
    result = client.send_request(prompt)
    return result["text"] if result.get("success") else ""


def call_llm(prompt: str) -> str:
    """
    兼容旧代码中的 call_llm
    """
    return call_gemini(prompt)


if __name__ == "__main__":
    client = GeminiClient()
    result = client.send_request("只回答 OK，不要输出其他内容。")

    print("success =", result.get("success"))
    print("text =", result.get("text"))
    print("error =", result.get("error"))