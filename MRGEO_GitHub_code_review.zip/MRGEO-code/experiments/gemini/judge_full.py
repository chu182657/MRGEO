"""
judge_full.py
=============
Gemini + ChatAnywhere 版本 GEO / MRGEOA 23 指标 Judge

用途：
1. 对每条生成结果进行 23 个原始指标评分
2. 要求 Gemini 只输出 JSON
3. 尽量减少 Gemini 输出 Markdown、解释文本、非 JSON 的问题
4. 失败时明确写入 judge_error，不假装成功
"""

import json
import re
from typing import Any, Dict, Optional

from gemini_client import GeminiClient


# ──────────────────────────────────────────────
# 23 个原始 Judge 指标
# 注意：后面的 19 指标表，是在评测完成后再筛选整理
# 这里必须先保留完整 23 个指标
# ──────────────────────────────────────────────

JUDGE_METRICS = [
    "citation_prominence",
    "answer_dominance",
    "visibility_overall",

    "relevance",
    "influence",
    "uniqueness",
    "diversity",
    "click_likelihood",
    "subjective_position",
    "subjective_volume",

    "attribution_accuracy",
    "faithfulness",
    "evidence_precision",
    "evidence_recall",
    "key_point_coverage",
    "semantic_contribution",
    "key_point_recall",
    "key_point_contradiction",

    "clarity",
    "insight",
    "coherence",
    "structure_quality",
    "readability",
]


# ──────────────────────────────────────────────
# 工具函数
# ──────────────────────────────────────────────

def clamp_float(value: Any, min_v: float = 0.0, max_v: float = 5.0) -> float:
    """
    把模型输出的分数安全转换为 0~5 的 float
    """
    try:
        v = float(value)
        v = max(min_v, min(max_v, v))
        return round(v, 4)
    except Exception:
        return 0.0


def extract_json(text: str) -> Optional[Dict[str, Any]]:
    """
    从 Gemini 返回文本中提取 JSON。

    兼容情况：
    1. 直接输出 JSON
    2. ```json ... ```
    3. 前后带解释，但中间有 {...}
    """
    if not text:
        return None

    cleaned = str(text).strip()

    # 去掉 Markdown 代码块
    cleaned = cleaned.replace("```json", "")
    cleaned = cleaned.replace("```JSON", "")
    cleaned = cleaned.replace("```", "")
    cleaned = cleaned.strip()

    # 有些模型会开头写 json
    cleaned = re.sub(r"^json\s*", "", cleaned, flags=re.IGNORECASE).strip()

    # 第一种：直接解析
    try:
        parsed = json.loads(cleaned)
        if isinstance(parsed, dict):
            return parsed
    except Exception:
        pass

    # 第二种：从文本中抓第一个大括号 JSON
    match = re.search(r"\{[\s\S]*\}", cleaned)
    if not match:
        return None

    candidate = match.group(0).strip()

    try:
        parsed = json.loads(candidate)
        if isinstance(parsed, dict):
            return parsed
    except Exception:
        return None

    return None


def default_fail(error_msg: str) -> Dict[str, Any]:
    """
    Judge 失败时返回统一结构。
    注意：这里分数全是 0，并且 success=False。
    后续 run_evaluation 会把 error 写进 judge_error。
    """
    row = {metric: 0.0 for metric in JUDGE_METRICS}
    row["success"] = False
    row["explanation"] = "评审失败。"
    row["error"] = error_msg
    return row


# ──────────────────────────────────────────────
# Prompt 构造
# ──────────────────────────────────────────────

def build_judge_prompt(
    query: str,
    response: str,
    source_text: str = "",
    method: str = "",
) -> str:
    """
    构造给 Gemini 的 Judge prompt。

    这里故意比 GPT 版本短很多：
    - 防止 Gemini 输出长解释
    - 防止 JSON 截断
    - 防止不按格式输出
    """

    query = str(query or "").strip()[:1000]
    response = str(response or "").strip()[:2500]
    source_text = str(source_text or "").strip()[:1800]
    method = str(method or "").strip()

    return f"""
你是一个严格的 GEO 评价器。请评价下面 response 的质量。

你必须只输出一个 JSON 对象。
不要输出 Markdown。
不要输出代码块。
不要输出 JSON 之外的解释文字。

评分范围：
0 = 完全失败
1 = 很差
2 = 较弱
3 = 一般
4 = 较好
5 = 非常好

特殊规则：
key_point_contradiction 表示关键点矛盾程度，越低越好。
0 = 没有矛盾，5 = 严重矛盾。
其他指标都是越高越好。

输入信息：

method:
{method}

query:
{query}

source_text:
{source_text}

response:
{response}

请严格按照下面 JSON 模板输出，必须保留所有字段名：

{{
  "citation_prominence": 0,
  "answer_dominance": 0,
  "visibility_overall": 0,

  "relevance": 0,
  "influence": 0,
  "uniqueness": 0,
  "diversity": 0,
  "click_likelihood": 0,
  "subjective_position": 0,
  "subjective_volume": 0,

  "attribution_accuracy": 0,
  "faithfulness": 0,
  "evidence_precision": 0,
  "evidence_recall": 0,
  "key_point_coverage": 0,
  "semantic_contribution": 0,
  "key_point_recall": 0,
  "key_point_contradiction": 0,

  "clarity": 0,
  "insight": 0,
  "coherence": 0,
  "structure_quality": 0,
  "readability": 0,

  "explanation": "150字以内说明主要评分理由"
}}
""".strip()


# ──────────────────────────────────────────────
# 核心 Judge 函数
# ──────────────────────────────────────────────

def judge_response(
    query: str,
    response: str,
    source_text: str = "",
    method: str = "",
    client: Optional[GeminiClient] = None,
) -> Dict[str, Any]:
    """
    对单条 response 进行 23 指标打分。

    返回：
    {
        指标1: 分数,
        指标2: 分数,
        ...
        success: True/False,
        explanation: "...",
        error: ""
    }
    """

    if not str(response or "").strip():
        return default_fail("response 为空")

    judge_client = client or GeminiClient()

    prompt = build_judge_prompt(
        query=query,
        response=response,
        source_text=source_text,
        method=method,
    )

    llm_result = judge_client.send_request(prompt)

    if not llm_result.get("success"):
        return default_fail(llm_result.get("error", "LLM 调用失败"))

    raw_text = llm_result.get("text", "")

    parsed = extract_json(raw_text)

    if not parsed:
        return default_fail("judge 输出无法解析为 JSON")

    row: Dict[str, Any] = {}

    for metric in JUDGE_METRICS:
        row[metric] = clamp_float(parsed.get(metric, 0.0))

    row["success"] = True
    row["explanation"] = str(parsed.get("explanation", "")).strip()[:300]
    row["error"] = str(parsed.get("error", "") or "").strip()

    return row


# ──────────────────────────────────────────────
# 单文件测试
# ──────────────────────────────────────────────

if __name__ == "__main__":
    demo = judge_response(
        query="What is the most popular sport in Karnataka?",
        source_text="Cricket is the most popular sport in Karnataka. Football also has a following in the state.",
        response="The most popular sport in Karnataka is cricket, while football also has a certain fan base.",
        method="m2geo",
    )

    print(json.dumps(demo, ensure_ascii=False, indent=2))