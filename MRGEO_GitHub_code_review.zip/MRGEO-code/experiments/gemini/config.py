"""
config.py
=========
GEO / MRGEOA 实验全局配置文件
Gemini + ChatAnywhere 版本

用途：
1. 已经生成好文章
2. 只负责调用 Gemini 做 23 指标 Judge 评分
3. 防止 Gemini 大量 JSON 解析失败、403、567、空表、废表
"""

from pathlib import Path
import os

# ──────────────────────────────────────────────
# 路径配置
# ──────────────────────────────────────────────

BASE_DIR = Path(__file__).resolve().parent

DATA_PATH = BASE_DIR / "data" / "samples.json"

OUTPUT_DIR = Path(os.getenv("MRGEO_OUTPUT_DIR", str(BASE_DIR / "outputs")))

# ──────────────────────────────────────────────
# API 配置
# ──────────────────────────────────────────────

# 方式一：直接在这里填你的 ChatAnywhere key
# API_KEY = "REMOVED_API_KEY"

# 方式二：从 PowerShell 环境变量读取
# PowerShell 设置方式：
# $env:API_KEY="REMOVED_API_KEY"

API_KEY = os.getenv("API_KEY", "")

# ChatAnywhere OpenAI-compatible 接口
API_BASE_URL = os.getenv(
    "API_BASE_URL",
    "https://api.chatanywhere.tech/v1/chat/completions"
)

# Gemini 模型名
# 注意：这里必须和 ChatAnywhere 后台支持的模型名完全一致
# 如果后台显示的是 gemini-2.0-flash，就改成 gemini-2.0-flash
# 如果后台显示的是 gemini-2.5-flash-preview-05-20，就保留下面这个
MODEL_NAME = os.getenv(
    "MODEL_NAME",
    "gemini-2.5-flash-preview-05-20"
)

# ──────────────────────────────────────────────
# GEO 方法列表：14 种方法
# ──────────────────────────────────────────────

METHOD_LIST = [
    "uniqueness",
    "simplification",
    "authority",
    "fluency",
    "terminology",
    "reputation",
    "citation",
    "statistics",
    "autogeo",
    "intent_geo",
    "multimodal",
    "multi_agent",
    "rag_based",
    "m2geo",
]

# ──────────────────────────────────────────────
# 运行参数：Gemini 慢速稳定版
# ──────────────────────────────────────────────

# 请求失败最多重试次数
MAX_RETRIES = 3

# Gemini / ChatAnywhere 不建议并发
# 当前评测脚本本身是串行，这里设 1
CONCURRENCY = 1

# Gemini Judge 可能比较慢，超时时间给足
TIMEOUT = 120.0

# 必须打开
# 之前你这里是 False，容易导致不真正打分
ENABLE_JUDGE = True

# Gemini 经 ChatAnywhere 调用时限流比较明显
# 1 秒太快，容易 403 / 567
# 先用 8 秒，稳定后最多再降到 5 秒
REQUEST_INTERVAL = 8.0

# 23 指标 JSON 输出较长，512 容易截断
MAX_OUTPUT_TOKENS = 2048

# Judge 打分建议低温，输出更稳定
TEMPERATURE = 0.1

# 是否启用 OpenAI JSON response_format
# 有些中转站 / Gemini 模型不支持，默认先关掉
# 如果后面确认支持，再改 True
USE_RESPONSE_FORMAT_JSON = False

# ──────────────────────────────────────────────
# 输出文件名配置
# ──────────────────────────────────────────────

EVAL_OUTPUT_NAME = "evaluation_results_full23_gemini_SAFE.csv"

TABLE_DIR_NAME = "tables_full23_gemini_SAFE"

FIGURE_DIR_NAME = "figures_full23_gemini_SAFE"

# ──────────────────────────────────────────────
# 启动校验
# ──────────────────────────────────────────────

INVALID_KEYS = [
    "",
    "在这里填你的ChatAnywhere_API_KEY",
    "你的ChatAnywhere_API_KEY",
    "你的key",
    "REMOVED_API_KEY",
]

# API clients validate credentials at request time; offline imports remain available.

if not API_BASE_URL.startswith("https://"):
    raise ValueError(
        f"❌ API_BASE_URL 配置异常：{API_BASE_URL}"
    )

if "chat/completions" not in API_BASE_URL:
    raise ValueError(
        "❌ API_BASE_URL 应该是 OpenAI-compatible chat/completions 地址，"
        "例如：https://api.chatanywhere.tech/v1/chat/completions"
    )

if not MODEL_NAME:
    raise ValueError("❌ MODEL_NAME 不能为空。")

# ──────────────────────────────────────────────
# 启动时打印关键信息，方便确认
# ──────────────────────────────────────────────

print(f"[config] BASE_DIR={BASE_DIR}")
print(f"[config] OUTPUT_DIR={OUTPUT_DIR}")
print(f"[config] MODEL_NAME={MODEL_NAME}")
print(f"[config] API_BASE_URL={API_BASE_URL}")
print(f"[config] REQUEST_INTERVAL={REQUEST_INTERVAL}")
print(f"[config] MAX_OUTPUT_TOKENS={MAX_OUTPUT_TOKENS}")
print(f"[config] ENABLE_JUDGE={ENABLE_JUDGE}")