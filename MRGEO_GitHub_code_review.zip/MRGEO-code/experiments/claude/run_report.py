"""
run_report.py
=============
汇总评测结果，导出正式图表和表格。
"""

import warnings
warnings.filterwarnings("ignore")

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import numpy as np
import pandas as pd
import seaborn as sns
from pathlib import Path
from scipy import stats

from config import OUTPUT_DIR

plt.rcParams["font.family"] = ["DejaVu Sans", "Arial", "sans-serif"]
plt.rcParams["axes.unicode_minus"] = False
plt.rcParams["figure.dpi"] = 150
plt.rcParams["savefig.dpi"] = 300
plt.rcParams["font.size"] = 11

BASELINE_METHODS = [
    "uniqueness", "simplification", "authority", "fluency",
    "terminology", "reputation", "citation", "statistics"
]
ADVANCED_METHODS = ["autogeo", "intent_geo", "multimodal", "multi_agent", "rag_based"]
M2GEO_METHODS = ["m2geo"]

OBJECTIVE_METRICS = ["relevance", "influence", "uniqueness", "diversity", "clickability"]
SUBJECTIVE_METRICS = ["subjective_positivity", "subjective_volubility"]
ALL_METRICS = OBJECTIVE_METRICS + SUBJECTIVE_METRICS
SUMMARY_METRICS = ["overall_objective_score", "overall_subjective_score", "overall_score"]

METHOD_LABELS = {
    "uniqueness": "Uniqueness",
    "simplification": "Simplification",
    "authority": "Authority",
    "fluency": "Fluency",
    "terminology": "Terminology",
    "reputation": "Reputation",
    "citation": "Citation",
    "statistics": "Statistics",
    "autogeo": "AutoGEO",
    "intent_geo": "Intent-GEO",
    "multimodal": "Multimodal",
    "multi_agent": "Multi-Agent",
    "rag_based": "RAG-based",
    "m2geo": "M²GEO",
}
METRIC_LABELS = {
    "relevance": "Relevance",
    "influence": "Influence",
    "uniqueness": "Uniqueness",
    "diversity": "Diversity",
    "clickability": "Clickability",
    "subjective_positivity": "Subj. Positivity",
    "subjective_volubility": "Subj. Volubility",
}
GROUP_COLORS = {"Baseline": "#4C72B0", "Advanced": "#DD8452", "M2GEO": "#55A868"}
METHOD_ORDER = BASELINE_METHODS + ADVANCED_METHODS + M2GEO_METHODS


def get_method_group(method: str) -> str:
    if method in BASELINE_METHODS:
        return "Baseline"
    if method in ADVANCED_METHODS:
        return "Advanced"
    return "M2GEO"


def ensure_dirs():
    tables_dir = OUTPUT_DIR / "tables"
    figures_dir = OUTPUT_DIR / "figures"
    tables_dir.mkdir(parents=True, exist_ok=True)
    figures_dir.mkdir(parents=True, exist_ok=True)
    return tables_dir, figures_dir


def load_and_prepare(input_csv: Path):
    df = pd.read_csv(input_csv, encoding="utf-8-sig")

    for col in ALL_METRICS + SUMMARY_METRICS:
        if col in df.columns:
            df[col] = pd.to_numeric(df[col], errors="coerce")

    available_metrics = [m for m in ALL_METRICS if m in df.columns]
    summary_metrics = [m for m in SUMMARY_METRICS if m in df.columns]
    agg_cols = available_metrics + summary_metrics

    method_mean = df.groupby("method")[agg_cols].mean(numeric_only=True).reset_index()
    method_std = df.groupby("method")[agg_cols].std(numeric_only=True).reset_index()

    existing_order = [m for m in METHOD_ORDER if m in method_mean["method"].values]
    other_methods = [m for m in method_mean["method"].values if m not in METHOD_ORDER]
    final_order = existing_order + other_methods

    method_mean = method_mean.set_index("method").reindex(final_order).reset_index()
    method_std = method_std.set_index("method").reindex(final_order).reset_index()

    method_mean["group"] = method_mean["method"].apply(get_method_group)
    method_mean["label"] = method_mean["method"].apply(lambda x: METHOD_LABELS.get(x, x))
    method_std["group"] = method_std["method"].apply(get_method_group)
    method_std["label"] = method_std["method"].apply(lambda x: METHOD_LABELS.get(x, x))

    return df, method_mean, method_std, available_metrics


def save_main_results_table(method_mean, available_metrics, tables_dir):
    cols = [m for m in available_metrics if m in method_mean.columns]
    if "overall_score" in method_mean.columns:
        cols += ["overall_score"]

    display_df = method_mean[["method", "group"] + cols].copy()
    display_df["method_label"] = display_df["method"].apply(lambda x: METHOD_LABELS.get(x, x))
    display_df.to_csv(tables_dir / "main_results_table.csv", index=False, encoding="utf-8-sig")

    latex_lines = [
        "\\begin{table*}[t]",
        "\\centering",
        "\\caption{Main Results: Comparison of GEO Methods}",
        "\\label{tab:main_results}",
        f"\\begin{{tabular}}{{l|l|{'c'*len(cols)}}}",
        "\\hline",
        " & ".join(["Method", "Group"] + [METRIC_LABELS.get(c, c) for c in cols]) + " \\\\",
        "\\hline",
    ]

    best_vals, second_vals = {}, {}
    for col in cols:
        s = display_df[col].dropna().sort_values(ascending=False).unique()
        if len(s) >= 1:
            best_vals[col] = s[0]
        if len(s) >= 2:
            second_vals[col] = s[1]

    current_group = None
    for _, row in display_df.iterrows():
        g = row["group"]
        if g != current_group:
            if current_group is not None:
                latex_lines.append("\\hline")
            current_group = g

        cells = [row["method_label"], g]
        for col in cols:
            val = row[col]
            if pd.isna(val):
                cells.append("-")
            else:
                t = f"{val:.3f}"
                if col in best_vals and abs(val - best_vals[col]) < 1e-12:
                    t = f"\\textbf{{{t}}}"
                elif col in second_vals and abs(val - second_vals[col]) < 1e-12:
                    t = f"\\underline{{{t}}}"
                cells.append(t)
        latex_lines.append(" & ".join(cells) + " \\\\")

    latex_lines += ["\\hline", "\\end{tabular}", "\\end{table*}"]
    (tables_dir / "main_results_table.tex").write_text("\n".join(latex_lines), encoding="utf-8")
    print("✅ 主结果表格已保存（CSV + LaTeX）")


def plot_group_comparison(method_mean, available_metrics, figures_dir):
    cols = [m for m in available_metrics if m in method_mean.columns]
    if not cols:
        return

    group_df = method_mean.groupby("group")[cols].mean().reindex(["Baseline", "Advanced", "M2GEO"]).dropna(how="all").reset_index()

    x = np.arange(len(cols))
    width = 0.25
    fig, ax = plt.subplots(figsize=(13, 6))

    for i, (_, row) in enumerate(group_df.iterrows()):
        gname = row["group"]
        vals = [row[c] for c in cols]
        ax.bar(x + i * width, vals, width, label=gname, color=GROUP_COLORS[gname], edgecolor="white", linewidth=0.5)

    ax.set_xticks(x + width)
    ax.set_xticklabels([METRIC_LABELS.get(c, c) for c in cols], rotation=20, ha="right")
    ax.set_ylim(0, 5.8)
    ax.set_title("Figure 3: Group-Level Comparison (Baseline vs Advanced vs M²GEO)", fontweight="bold")
    ax.legend()
    plt.tight_layout()
    plt.savefig(figures_dir / "fig3_group_comparison.png", dpi=300, bbox_inches="tight")
    plt.close()
    print("✅ 图3 已生成")


def plot_significance_test(df, figures_dir):
    if "overall_score" not in df.columns or "m2geo" not in df["method"].values:
        return

    m2 = df[df["method"] == "m2geo"]["overall_score"].dropna().values
    if len(m2) < 3:
        return

    results = []
    for method in [m for m in METHOD_ORDER if m != "m2geo" and m in df["method"].values]:
        x = df[df["method"] == method]["overall_score"].dropna().values
        n = min(len(m2), len(x))
        if n < 3:
            continue
        a, b = m2[:n], x[:n]
        try:
            _, p_val = stats.wilcoxon(a, b, alternative="greater")
        except Exception:
            p_val = 1.0

        sig = "***" if p_val < 0.001 else ("**" if p_val < 0.01 else ("*" if p_val < 0.05 else ""))
        results.append({
            "method": METHOD_LABELS.get(method, method),
            "group": get_method_group(method),
            "neg_log_p": -np.log10(max(p_val, 1e-10)),
            "sig": sig
        })

    if not results:
        return

    res_df = pd.DataFrame(results)
    fig, ax = plt.subplots(figsize=(12, 5))
    bars = ax.barh(res_df["method"], res_df["neg_log_p"], color=[GROUP_COLORS[g] for g in res_df["group"]])

    for bar, sig in zip(bars, res_df["sig"]):
        if sig:
            ax.text(bar.get_width() + 0.05, bar.get_y() + bar.get_height()/2, sig, va="center")

    ax.axvline(-np.log10(0.05), color="orange", linestyle="--", linewidth=1.2, label="p=0.05")
    ax.axvline(-np.log10(0.01), color="red", linestyle="--", linewidth=1.2, label="p=0.01")
    ax.axvline(-np.log10(0.001), color="darkred", linestyle="--", linewidth=1.2, label="p=0.001")
    ax.set_xlabel("-log10(p-value)")
    ax.set_title("Figure 7: Significance Test – M²GEO vs Other Methods", fontweight="bold")
    plt.tight_layout()
    plt.savefig(figures_dir / "fig7_significance_test.png", dpi=300, bbox_inches="tight")
    plt.close()
    print("✅ 图7 已生成")


def plot_top3_per_metric(method_mean, available_metrics, figures_dir):
    cols = [m for m in available_metrics if m in method_mean.columns]
    if not cols:
        return

    fig, axes = plt.subplots(len(cols), 1, figsize=(10, max(3, len(cols) * 2.2)))
    if len(cols) == 1:
        axes = [axes]

    for ax, metric in zip(axes, cols):
        sub = method_mean.dropna(subset=[metric])[["label", "group", metric]].copy()
        if sub.empty:
            ax.axis("off")
            continue
        top3 = sub.nlargest(3, metric)
        bars = ax.barh(top3["label"], top3[metric], color=[GROUP_COLORS[g] for g in top3["group"]])
        for bar, val in zip(bars, top3[metric]):
            ax.text(bar.get_width() + 0.03, bar.get_y() + bar.get_height()/2, f"{val:.3f}", va="center", fontsize=9)
        ax.set_xlim(0, 5.8)
        ax.set_title(f"Top 3 – {METRIC_LABELS.get(metric, metric)}", fontsize=10, fontweight="bold")

    plt.tight_layout()
    plt.savefig(figures_dir / "fig9_top3_per_metric.png", dpi=300, bbox_inches="tight")
    plt.close()
    print("✅ 图9 已生成")


def save_ranking_table(method_mean, tables_dir):
    if "overall_score" not in method_mean.columns:
        return
    ranking = method_mean[["method", "group", "overall_score"]].dropna().copy()
    ranking["method_label"] = ranking["method"].map(lambda x: METHOD_LABELS.get(x, x))
    ranking = ranking.sort_values("overall_score", ascending=False).reset_index(drop=True)
    ranking.insert(0, "rank", np.arange(1, len(ranking) + 1))
    ranking.to_csv(tables_dir / "method_ranking.csv", index=False, encoding="utf-8-sig")
    print("✅ 排名表已保存")


def main():
    input_csv = OUTPUT_DIR / "scores" / "evaluation_results.csv"
    if not input_csv.exists():
        raise FileNotFoundError(f"未找到评测结果文件: {input_csv}")

    tables_dir, figures_dir = ensure_dirs()
    df, method_mean, method_std, available_metrics = load_and_prepare(input_csv)

    save_main_results_table(method_mean, available_metrics, tables_dir)
    save_ranking_table(method_mean, tables_dir)

    # 你原有其他图函数可以保留调用，这里只替换修复过的关键函数
    plot_group_comparison(method_mean, available_metrics, figures_dir)
    plot_significance_test(df, figures_dir)
    plot_top3_per_metric(method_mean, available_metrics, figures_dir)

    print(f"\n🎉 完成！\n表格目录：{tables_dir}\n图片目录：{figures_dir}")


if __name__ == "__main__":
    main()
