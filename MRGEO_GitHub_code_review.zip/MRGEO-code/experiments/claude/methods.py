"""
methods.py
==========
GEO 实验各方法的 Prompt 构造模块
"""

from typing import Dict, Any, List


# ──────────────────────────────────────────────
# 工具函数
# ──────────────────────────────────────────────

def _format_documents(documents: List[Dict]) -> str:
    """将文档列表格式化为字符串"""
    if not documents:
        return "（无参考文档）"
    lines = []
    for i, doc in enumerate(documents, 1):
        text = doc.get("text", "").strip()
        lines.append(f"[文档{i}] {text}")
    return "\n".join(lines)


# ──────────────────────────────────────────────
# 各方法 Prompt 构造
# ──────────────────────────────────────────────

def _build_uniqueness(query: str, docs_str: str) -> str:
    return (
        f"请根据以下参考文档，用独特且新颖的视角回答问题。\n\n"
        f"问题：{query}\n\n参考文档：\n{docs_str}\n\n请给出你的回答："
    )


def _build_simplification(query: str, docs_str: str) -> str:
    return (
        f"请用简洁易懂的语言回答以下问题，避免专业术语，让普通用户也能理解。\n\n"
        f"问题：{query}\n\n参考文档：\n{docs_str}\n\n请给出你的回答："
    )


def _build_authority(query: str, docs_str: str) -> str:
    return (
        f"请以权威专家的口吻回答以下问题，体现专业性和可信度。\n\n"
        f"问题：{query}\n\n参考文档：\n{docs_str}\n\n请给出你的回答："
    )


def _build_fluency(query: str, docs_str: str) -> str:
    return (
        f"请用流畅自然的语言回答以下问题，确保语句通顺、表达清晰。\n\n"
        f"问题：{query}\n\n参考文档：\n{docs_str}\n\n请给出你的回答："
    )


def _build_terminology(query: str, docs_str: str) -> str:
    return (
        f"请在回答中适当使用专业术语，体现领域专业知识。\n\n"
        f"问题：{query}\n\n参考文档：\n{docs_str}\n\n请给出你的回答："
    )


def _build_reputation(query: str, docs_str: str) -> str:
    return (
        f"请在回答中引用知名机构或权威来源，增强回答的可信度。\n\n"
        f"问题：{query}\n\n参考文档：\n{docs_str}\n\n请给出你的回答："
    )


def _build_citation(query: str, docs_str: str) -> str:
    return (
        f"请在回答中明确引用参考文档中的内容，并标注来源。\n\n"
        f"问题：{query}\n\n参考文档：\n{docs_str}\n\n请给出你的回答："
    )


def _build_statistics(query: str, docs_str: str) -> str:
    return (
        f"请在回答中尽量引用数据和统计信息来支撑观点。\n\n"
        f"问题：{query}\n\n参考文档：\n{docs_str}\n\n请给出你的回答："
    )


def _build_autogeo(query: str, docs_str: str) -> str:
    return (
        f"你是一个专为生成式引擎优化（GEO）设计的智能助手。"
        f"请自动选择最优策略回答以下问题，使回答更易被AI搜索引擎引用。\n\n"
        f"问题：{query}\n\n参考文档：\n{docs_str}\n\n请给出你的回答："
    )


def _build_intent_geo(query: str, docs_str: str) -> str:
    return (
        f"请先分析用户的搜索意图，再针对该意图给出最符合需求的回答。\n\n"
        f"问题：{query}\n\n参考文档：\n{docs_str}\n\n请给出你的回答："
    )


def _build_multimodal(query: str, docs_str: str) -> str:
    return (
        f"请用图文结合的方式组织回答（文字描述为主，必要时说明可配合图表展示）。\n\n"
        f"问题：{query}\n\n参考文档：\n{docs_str}\n\n请给出你的回答："
    )


def _build_multi_agent(query: str, docs_str: str) -> str:
    return (
        f"请模拟多个专家角色（如：研究员、实践者、评论员）分别给出观点，最后综合得出结论。\n\n"
        f"问题：{query}\n\n参考文档：\n{docs_str}\n\n请给出你的回答："
    )


def _build_rag_based(query: str, docs_str: str) -> str:
    return (
        f"请严格基于以下参考文档内容回答问题，不要添加文档中没有的信息。\n\n"
        f"问题：{query}\n\n参考文档：\n{docs_str}\n\n请给出你的回答："
    )


def _build_m2geo(query: str, docs_str: str) -> str:
    return (
        f"你是一个多维度GEO优化助手。请综合运用权威引用、数据支撑、清晰结构、"
        f"专业术语和独特视角，生成一篇高质量、易被生成式搜索引擎引用的回答。\n\n"
        f"问题：{query}\n\n参考文档：\n{docs_str}\n\n请给出你的回答："
    )


# ──────────────────────────────────────────────
# 方法注册表
# ──────────────────────────────────────────────

_METHOD_REGISTRY = {
    "uniqueness":    _build_uniqueness,
    "simplification": _build_simplification,
    "authority":     _build_authority,
    "fluency":       _build_fluency,
    "terminology":   _build_terminology,
    "reputation":    _build_reputation,
    "citation":      _build_citation,
    "statistics":    _build_statistics,
    "autogeo":       _build_autogeo,
    "intent_geo":    _build_intent_geo,
    "multimodal":    _build_multimodal,
    "multi_agent":   _build_multi_agent,
    "rag_based":     _build_rag_based,
    "m2geo":         _build_m2geo,
}


# ──────────────────────────────────────────────
# 对外接口
# ──────────────────────────────────────────────

def list_methods() -> List[str]:
    """返回所有支持的方法名列表"""
    return list(_METHOD_REGISTRY.keys())


def build_prompt(method_name: str, sample: Dict[str, Any]) -> str:
    """
    根据方法名和样本构造 prompt。

    Parameters
    ----------
    method_name : str
        方法名，需在 list_methods() 中。
    sample : dict
        包含 'query' 和 'documents' 字段的样本字典。

    Returns
    -------
    str
        构造好的 prompt 字符串。
    """
    if method_name not in _METHOD_REGISTRY:
        raise ValueError(
            f"未知方法：{method_name}，支持的方法：{list_methods()}"
        )

    query = sample.get("query", "").strip()
    documents = sample.get("documents", [])
    docs_str = _format_documents(documents)

    builder = _METHOD_REGISTRY[method_name]
    return builder(query, docs_str)