"""
gemini_client.py
================
通用 API 客户端封装（OpenAI-compatible chat/completions）。

说明：
- 保留 GeminiClient / call_gemini 命名以兼容旧代码
- 实际可用于 Claude Haiku / DeepSeek / 其他 OpenAI 兼容网关
"""

import logging
import time
from typing import Any, Dict, Optional

import requests

from config import (
    API_KEY,
    API_BASE_URL,
    MODEL_NAME,
    MAX_RETRIES,
    OUTPUT_DIR,
    TIMEOUT,
    TEMPERATURE,
    MAX_OUTPUT_TOKENS,
)


def _build_chat_url(base_url: str) -> str:
    """
    兼容两种配置：
    1) API_BASE_URL = https://xxx/v1
    2) API_BASE_URL = https://xxx/v1/chat/completions
    """
    base = (base_url or "").rstrip("/")
    if base.endswith("/chat/completions"):
        return base
    return f"{base}/chat/completions"


class GeminiClient:
    """
    API 客户端封装（名字保留 GeminiClient 以兼容其他文件导入）。
    """

    def __init__(
        self,
        api_key: Optional[str] = None,
        model_name: Optional[str] = None,
        max_retries: Optional[int] = None,
        timeout: Optional[float] = None,
    ) -> None:
        self.api_key = api_key or API_KEY
        self.model_name = model_name or MODEL_NAME
        self.max_retries = max_retries if max_retries is not None else MAX_RETRIES
        self.timeout = timeout if timeout is not None else TIMEOUT
        self.url = _build_chat_url(API_BASE_URL)
        self.logger = self._build_logger()

    def _build_logger(self) -> logging.Logger:
        """构建日志（控制台 + 文件）。"""
        logger = logging.getLogger("gemini_client")
        if logger.handlers:
            return logger

        logger.setLevel(logging.INFO)
        formatter = logging.Formatter(
            "%(asctime)s | %(levelname)s | %(name)s | %(message)s"
        )

        stream_handler = logging.StreamHandler()
        stream_handler.setFormatter(formatter)
        logger.addHandler(stream_handler)

        try:
            log_dir = OUTPUT_DIR / "logs"
            log_dir.mkdir(parents=True, exist_ok=True)
            file_handler = logging.FileHandler(
                log_dir / "gemini_client.log", encoding="utf-8"
            )
            file_handler.setFormatter(formatter)
            logger.addHandler(file_handler)
        except Exception:
            # 文件日志失败不影响主流程
            pass

        return logger

    @staticmethod
    def _ok(text: str, raw: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        return {"success": True, "text": text, "error": None, "raw": raw}

    @staticmethod
    def _fail(error_msg: str) -> Dict[str, Any]:
        return {"success": False, "text": "", "error": error_msg, "raw": None}

    def send_request(self, prompt: str) -> Dict[str, Any]:
        """
        发送单次请求（含重试逻辑）。

        返回格式：
        {
            "success": True/False,
            "text": "回答内容",
            "error": "错误信息或None",
            "raw": {...原始响应...}
        }
        """
        if not self.api_key or self.api_key in ("你的_api_key", ""):
            error_msg = "API Key 未配置，请在 config.py 或环境变量中设置 API_KEY。"
            self.logger.error(error_msg)
            return self._fail(error_msg)

        if not API_BASE_URL:
            error_msg = "API_BASE_URL 未配置。"
            self.logger.error(error_msg)
            return self._fail(error_msg)

        headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {self.api_key}",
        }

        payload = {
            "model": self.model_name,
            "messages": [{"role": "user", "content": prompt}],
            "temperature": TEMPERATURE,
            "max_tokens": MAX_OUTPUT_TOKENS,
        }

        last_error = "未知错误"

        for attempt in range(1, self.max_retries + 1):
            try:
                self.logger.info(
                    "发送请求 attempt=%s/%s model=%s url=%s",
                    attempt, self.max_retries, self.model_name, self.url
                )

                response = requests.post(
                    self.url,
                    headers=headers,
                    json=payload,
                    timeout=self.timeout,
                )

                # 可重试状态码
                if response.status_code in (429, 500, 502, 503, 504):
                    last_error = f"服务繁忙/限流 status={response.status_code}, body={response.text[:300]}"
                    self.logger.warning(last_error)
                    if attempt < self.max_retries:
                        wait = min(2 ** attempt, 10)
                        self.logger.info("等待 %s 秒后重试...", wait)
                        time.sleep(wait)
                        continue
                    return self._fail(last_error)

                response.raise_for_status()
                result = response.json()

                # 解析 OpenAI-compatible 响应
                choices = result.get("choices") or []
                text = ""
                if choices:
                    message = choices[0].get("message") or {}
                    content = message.get("content")

                    # 常见：字符串
                    if isinstance(content, str):
                        text = content.strip()
                    # 少数网关：数组分片
                    elif isinstance(content, list):
                        parts = []
                        for seg in content:
                            if isinstance(seg, dict) and "text" in seg:
                                parts.append(str(seg["text"]))
                        text = "".join(parts).strip()

                if not text:
                    last_error = f"响应结构异常或无文本内容: {str(result)[:500]}"
                    self.logger.error(last_error)
                else:
                    self.logger.info("请求成功，返回长度=%s字符", len(text))
                    return self._ok(text, raw=result)

            except requests.exceptions.Timeout:
                last_error = f"请求超时（>{self.timeout}s）"
                self.logger.warning("请求超时，attempt=%s/%s", attempt, self.max_retries)

            except requests.exceptions.RequestException as exc:
                last_error = f"请求异常: {exc}"
                self.logger.warning(
                    "请求失败，attempt=%s/%s，error=%s",
                    attempt, self.max_retries, exc
                )

            except Exception as exc:
                last_error = f"未预期异常: {exc}"
                self.logger.exception(
                    "未预期异常，attempt=%s/%s", attempt, self.max_retries
                )

            # 指数退避
            if attempt < self.max_retries:
                wait = min(2 ** attempt, 10)
                self.logger.info("等待 %s 秒后重试...", wait)
                time.sleep(wait)

        self.logger.error("请求最终失败: %s", last_error)
        return self._fail(last_error)


def call_gemini(prompt: str) -> str:
    """
    简化调用函数（兼容旧代码）：
    - 成功返回文本字符串
    - 失败返回空字符串
    """
    client = GeminiClient()
    result = client.send_request(prompt)
    return result["text"] if result["success"] else ""


if __name__ == "__main__":
    print("测试 API 连通性...")
    answer = call_gemini("你好，请用一句话介绍你自己。")
    if answer:
        print(f"✅ API 连通成功！回答：{answer}")
    else:
        print("❌ API 调用失败，请检查 API Key / API_BASE_URL / MODEL_NAME。")
