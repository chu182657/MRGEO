"""
run_evaluation.py
=================
读取生成结果，计算所有指标并保存评测结果。

自动指标：
    - word_count
    - positive_word_count
    - unique_word_ratio

LLM 评分（7个维度）：
    - relevance
    - influence
    - uniqueness
    - diversity
    - clickability
    - subjective_positivity
    - subjective_volubility

汇总分：
    - overall_objective_score
    - overall_subjective_score
    - overall_score
"""

import csv
import json
import logging
from pathlib import Path
from typing import Any, Dict, List

from config import ENABLE_JUDGE, OUTPUT_DIR
from judge import judge_response
from metrics import tokenize, word_count, unique_word_ratio


POSITIVE_WORDS = {
    "good", "great", "excellent", "amazing", "wonderful", "fantastic",
    "outstanding", "best", "top", "leading", "successful", "famous",
    "popular", "important", "significant", "notable", "remarkable",
    "impressive", "valuable", "effective", "powerful", "strong",
    "beautiful", "unique", "innovative", "advanced", "superior",
    "celebrated", "renowned", "prestigious", "award", "champion",
    "victory", "win", "achievement", "success", "proud",
    "优秀", "出色", "卓越", "杰出", "著名", "重要", "显著",
    "成功", "领先", "最佳", "顶尖", "独特", "创新", "先进",
    "强大", "有效", "美好", "辉煌", "荣誉", "冠军", "胜利",
}


def count_positive_words(text: str) -> int:
    """统计积极词出现总次数（非去重）。"""
    if not text:
        return 0
    tokens = tokenize(text)
    pos_set = {w.lower() for w in POSITIVE_WORDS}
    return sum(1 for tk in tokens if tk in pos_set)


def setup_logger() -> logging.Logger:
    logger = logging.getLogger("run_evaluation")
    if logger.handlers:
        return logger
    logger.setLevel(logging.INFO)
    formatter = logging.Formatter("%(asctime)s | %(levelname)s | %(message)s")
    sh = logging.StreamHandler()
    sh.setFormatter(formatter)
    logger.addHandler(sh)

    log_dir = OUTPUT_DIR / "logs"
    log_dir.mkdir(parents=True, exist_ok=True)
    fh = logging.FileHandler(log_dir / "evaluation.log", encoding="utf-8")
    fh.setFormatter(formatter)
    logger.addHandler(fh)
    return logger


def load_generation_records(input_path: Path) -> List[Dict[str, Any]]:
    """读取 jsonl/json 生成结果。"""
    if not input_path.exists():
        raise FileNotFoundError(f"生成结果文件不存在: {input_path}")

    suffix = input_path.suffix.lower()

    if suffix == ".jsonl":
        records: List[Dict[str, Any]] = []
        with input_path.open("r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if line:
                    records.append(json.loads(line))
        return records

    if suffix == ".json":
        with input_path.open("r", encoding="utf-8") as f:
            loaded = json.load(f)
        if isinstance(loaded, list):
            return loaded
        if isinstance(loaded, dict) and isinstance(loaded.get("results"), list):
            return loaded["results"]
        raise ValueError("JSON 格式错误：应为 list 或 {'results': [...]}")

    raise ValueError(f"不支持的文件类型: {suffix}")


def evaluate_record(item: Dict[str, Any], enable_judge: bool) -> Dict[str, Any]:
    sample_id = str(item.get("sample_id", ""))
    method = str(item.get("method", "unknown"))
    query = str(item.get("query", ""))

    # 兼容多种字段名
    response = str(
        item.get("generated_response")
        or item.get("generated_answer")
        or item.get("response")
        or ""
    ).strip()

    wc = word_count(response)
    pwc = count_positive_words(response)
    uwr = round(unique_word_ratio(response), 6)

    row: Dict[str, Any] = {
        "sample_id": sample_id,
        "method": method,
        "word_count": wc,
        "positive_word_count": pwc,
        "unique_word_ratio": uwr,
        "relevance": "",
        "influence": "",
        "uniqueness": "",
        "diversity": "",
        "clickability": "",
        "subjective_positivity": "",
        "subjective_volubility": "",
        "overall_objective_score": "",
        "overall_subjective_score": "",
        "overall_score": "",
        "judge_explanation": "",
        "judge_error": "",
    }

    if enable_judge:
        if not response:
            row["judge_error"] = "空回答，跳过LLM评分"
            return row

        result = judge_response(query=query, response=response)
        row["relevance"] = result.get("relevance", "")
        row["influence"] = result.get("influence", "")
        row["uniqueness"] = result.get("uniqueness", "")
        row["diversity"] = result.get("diversity", "")
        row["clickability"] = result.get("clickability", "")
        row["subjective_positivity"] = result.get("subjective_positivity", "")
        row["subjective_volubility"] = result.get("subjective_volubility", "")
        row["overall_objective_score"] = result.get("overall_objective_score", "")
        row["overall_subjective_score"] = result.get("overall_subjective_score", "")
        row["overall_score"] = result.get("overall_score", "")
        row["judge_explanation"] = result.get("explanation", "")
        row["judge_error"] = result.get("error", "")

    return row


FIELDNAMES = [
    "sample_id", "method",
    "word_count", "positive_word_count", "unique_word_ratio",
    "relevance", "influence", "uniqueness", "diversity", "clickability",
    "subjective_positivity", "subjective_volubility",
    "overall_objective_score", "overall_subjective_score", "overall_score",
    "judge_explanation", "judge_error",
]


def save_csv(rows: List[Dict[str, Any]], output_path: Path) -> None:
    output_path.parent.mkdir(parents=True, exist_ok=True)
    with output_path.open("w", encoding="utf-8-sig", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=FIELDNAMES)
        writer.writeheader()
        writer.writerows(rows)


def main():
    logger = setup_logger()

    jsonl_path = OUTPUT_DIR / "generations" / "generation_results.jsonl"
    json_path = OUTPUT_DIR / "generation_results.json"

    if jsonl_path.exists():
        input_file = jsonl_path
    elif json_path.exists():
        input_file = json_path
    else:
        raise FileNotFoundError(
            f"未找到生成结果文件，请先运行生成脚本。\n查找路径：{jsonl_path} 或 {json_path}"
        )

    logger.info("开始评测，输入文件: %s", input_file)
    records = load_generation_records(input_file)
    logger.info("读取到 %s 条生成记录", len(records))

    rows: List[Dict[str, Any]] = []
    for idx, item in enumerate(records, start=1):
        try:
            rows.append(evaluate_record(item, enable_judge=ENABLE_JUDGE))
            if idx % 50 == 0:
                logger.info("评测进度: %s/%s", idx, len(records))
        except Exception as e:
            logger.exception(
                "评测失败 sample_id=%s method=%s error=%s",
                item.get("sample_id"), item.get("method"), e
            )

    output_file = OUTPUT_DIR / "scores" / "evaluation_results.csv"
    save_csv(rows, output_file)

    logger.info("评测完成，共写入 %s 条，输出: %s", len(rows), output_file)
    print(f"\n✅ 评测完成！共 {len(rows)} 条记录")
    print(f"   结果保存在：{output_file}")


if __name__ == "__main__":
    main()
