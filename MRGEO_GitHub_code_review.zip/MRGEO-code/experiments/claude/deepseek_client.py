import logging
import time
from typing import Any, Dict, Optional

import requests

from config import (
    API_BASE_URL,   # 例如: https://xxx/v1
    API_KEY,
    MAX_RETRIES,
    MODEL_NAME,
    OUTPUT_DIR,
    REQUEST_INTERVAL,
    TIMEOUT,
    TEMPERATURE,
    MAX_OUTPUT_TOKENS,
)


class LLMClient:
    """
    通用 OpenAI-Compatible chat/completions 客户端（适配 Claude/DeepSeek/其他网关）

    特性：
    - send_request(prompt) 统一调用入口
    - 自动重试 + 指数退避
    - 超时处理
    - 429/5xx 重试
    - 基本日志记录
    - 统一返回格式，不向上抛致命异常
    """

    def __init__(
        self,
        api_key: Optional[str] = None,
        model_name: Optional[str] = None,
        max_retries: Optional[int] = None,
        timeout: Optional[float] = None,
        base_url: Optional[str] = None,
    ) -> None:
        self.api_key = api_key or API_KEY
        self.model_name = model_name or MODEL_NAME
        self.max_retries = max_retries if max_retries is not None else MAX_RETRIES
        self.timeout = timeout if timeout is not None else TIMEOUT
        self.base_url = (base_url or API_BASE_URL).rstrip("/")
        self.url = self._build_chat_url(self.base_url)
        self.logger = self._build_logger()
        self._last_request_ts = 0.0

    @staticmethod
    def _build_chat_url(base_url: str) -> str:
        # 兼容两种写法：
        # 1) base_url=.../v1
        # 2) base_url=.../v1/chat/completions
        if base_url.endswith("/chat/completions"):
            return base_url
        return f"{base_url}/chat/completions"

    def _build_logger(self) -> logging.Logger:
        logger = logging.getLogger("llm_client")
        if logger.handlers:
            return logger

        logger.setLevel(logging.INFO)
        formatter = logging.Formatter(
            "%(asctime)s | %(levelname)s | %(name)s | %(message)s"
        )

        stream_handler = logging.StreamHandler()
        stream_handler.setFormatter(formatter)
        logger.addHandler(stream_handler)

        try:
            log_dir = OUTPUT_DIR / "logs"
            log_dir.mkdir(parents=True, exist_ok=True)
            file_handler = logging.FileHandler(log_dir / "llm_client.log", encoding="utf-8")
            file_handler.setFormatter(formatter)
            logger.addHandler(file_handler)
        except Exception:
            pass

        return logger

    @staticmethod
    def _ok(text: str, raw: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        return {"success": True, "text": text, "error": None, "raw": raw}

    @staticmethod
    def _fail(error_msg: str) -> Dict[str, Any]:
        return {"success": False, "text": "", "error": error_msg, "raw": None}

    def _rate_limit_sleep(self) -> None:
        """按 REQUEST_INTERVAL 做最小请求间隔控制。"""
        now = time.time()
        delta = now - self._last_request_ts
        if delta < REQUEST_INTERVAL:
            time.sleep(REQUEST_INTERVAL - delta)
        self._last_request_ts = time.time()

    def send_request(self, prompt: str, system_prompt: Optional[str] = None) -> Dict[str, Any]:
        """
        发送单次请求（内含重试逻辑）。

        返回：
        {
          "success": true/false,
          "text": "...",
          "error": "...",
          "raw": {...}
        }
        """
        if not self.api_key:
            msg = "API_KEY 未配置，请先设置环境变量 API_KEY。"
            self.logger.error(msg)
            return self._fail(msg)

        if not self.base_url:
            msg = "API_BASE_URL 未配置。"
            self.logger.error(msg)
            return self._fail(msg)

        messages = []
        if system_prompt:
            messages.append({"role": "system", "content": system_prompt})
        messages.append({"role": "user", "content": prompt})

        headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {self.api_key}",
        }
        payload: Dict[str, Any] = {
            "model": self.model_name,
            "messages": messages,
            "temperature": TEMPERATURE,
            "max_tokens": MAX_OUTPUT_TOKENS,  # OpenAI兼容网关通常使用这个字段
        }

        last_error = "未知错误"
        for attempt in range(1, self.max_retries + 1):
            self._rate_limit_sleep()
            try:
                self.logger.info(
                    "发送 LLM 请求 attempt=%s/%s model=%s",
                    attempt,
                    self.max_retries,
                    self.model_name,
                )
                response = requests.post(
                    self.url,
                    headers=headers,
                    json=payload,
                    timeout=self.timeout,
                )

                # 对常见可重试状态码单独处理
                if response.status_code in (429, 500, 502, 503, 504):
                    last_error = f"服务繁忙/限流，status={response.status_code}, body={response.text[:300]}"
                    self.logger.warning(last_error)
                    if attempt < self.max_retries:
                        time.sleep(min(2 ** attempt, 8))
                        continue
                    return self._fail(last_error)

                response.raise_for_status()
                result = response.json()

                choices = result.get("choices") or []
                text = ""
                if choices:
                    message = choices[0].get("message") or {}
                    content = message.get("content")

                    # 兼容 content 为字符串或分段数组
                    if isinstance(content, str):
                        text = content.strip()
                    elif isinstance(content, list):
                        parts = []
                        for seg in content:
                            if isinstance(seg, dict) and "text" in seg:
                                parts.append(str(seg["text"]))
                        text = "".join(parts).strip()

                if not text:
                    last_error = f"响应结构异常或无文本内容: {str(result)[:500]}"
                    self.logger.error(last_error)
                else:
                    return self._ok(text, raw=result)

            except requests.exceptions.Timeout:
                last_error = f"请求超时（>{self.timeout}s）"
                self.logger.warning("请求超时 attempt=%s/%s", attempt, self.max_retries)
            except requests.exceptions.RequestException as exc:
                last_error = f"请求异常: {exc}"
                self.logger.warning(
                    "请求失败 attempt=%s/%s error=%s",
                    attempt,
                    self.max_retries,
                    exc,
                )
            except Exception as exc:
                last_error = f"未预期异常: {exc}"
                self.logger.exception("未预期异常 attempt=%s/%s", attempt, self.max_retries)

            if attempt < self.max_retries:
                time.sleep(min(2 ** attempt, 8))

        self.logger.error("请求最终失败: %s", last_error)
        return self._fail(last_error)


def call_llm(prompt: str, system_prompt: Optional[str] = None) -> str:
    """
    简化封装：
    - 成功返回文本
    - 失败返回空字符串（不抛异常）
    """
    client = LLMClient()
    result = client.send_request(prompt, system_prompt=system_prompt)
    return result["text"] if result["success"] else ""
