"""
data_loader.py
==============
加载样本数据。

默认读取 data/samples.json。
"""

import json
import re
from pathlib import Path
from typing import Any, Dict, List, Optional
from urllib.parse import unquote


def load_samples(path: Optional[str] = None) -> List[Dict[str, Any]]:
    """
    加载样本数据，默认读取 data/samples.json。

    参数：
        path: 可选，指定文件路径。不填则自动找 data/samples.json。

    返回：
        List[Dict]，每个元素包含 sample_id、query、documents 字段。
    """
    base = Path(__file__).resolve().parent
    file_path = Path(path) if path is not None else (base / "data" / "samples.json")

    if not file_path.exists():
        raise FileNotFoundError(f"样本文件不存在: {file_path}")

    with file_path.open("r", encoding="utf-8") as f:
        data = json.load(f)

    if isinstance(data, list):
        samples = data
    elif isinstance(data, dict) and "samples" in data and isinstance(data["samples"], list):
        samples = data["samples"]
    else:
        raise ValueError("samples.json 格式错误，应为 list 或包含 list 类型 samples 的 dict。")

    return samples


def extract_query_from_url(url: str) -> str:
    """
    从URL中提取主题，生成query。
    """
    if not url:
        return "Tell me about this topic."

    url = url.strip()
    parts = url.rstrip("/").split("/")
    if not parts:
        return "Tell me about this topic."

    last_part = unquote(parts[-1])  # URL decode
    topic = last_part.replace("_", " ").replace("-", " ")
    topic = re.sub(r"\.(html|htm|php|asp)$", "", topic, flags=re.IGNORECASE).strip()

    if not topic:
        return "Tell me about this topic."

    if "wiki" in url.lower():
        return f"What is {topic}?"
    return f"Tell me about {topic}."


def extract_query_from_text(text: str) -> str:
    """
    从文本中提取主题，生成query。
    """
    if not text:
        return "Tell me about this topic."

    lines = [l.strip() for l in text.strip().split("\n") if l.strip()]
    if not lines:
        return "Tell me about this topic."

    first_line = lines[0]
    if len(first_line) > 100:
        words = first_line.split()[:10]
        first_line = " ".join(words)

    first_line = re.sub(r"\s+", " ", first_line).strip(" -:|")
    if not first_line:
        return "Tell me about this topic."

    return f"Tell me about {first_line}."


def load_samples_from_geo_text(txt_path: Path, verbose: bool = False) -> List[Dict[str, Any]]:
    """
    从 GEO_bench_url_cleaned.txt 读取样本并转换为结构化数据。
    """
    if not txt_path.exists():
        raise FileNotFoundError(f"源文件不存在: {txt_path}")

    if verbose:
        print(f"正在读取文件: {txt_path}")

    with txt_path.open("r", encoding="utf-8") as f:
        content = f.read()

    # 更稳：按“样本编号”切块，降低对分隔线格式的依赖
    blocks = re.split(r"(?=样本编号:\s*\d+)", content)

    if verbose:
        print(f"总共拆分出 {len(blocks)} 个块")

    samples_dict: Dict[str, List[Dict[str, str]]] = {}

    for block in blocks:
        block = block.strip()
        if not block:
            continue

        sample_match = re.search(r"样本编号:\s*(\d+)", block)
        if not sample_match:
            continue
        sample_id = sample_match.group(1)

        doc_match = re.search(r"文档编号:\s*(\d+)", block)
        doc_id = doc_match.group(1) if doc_match else "1"

        url_match = re.search(r"URL:\s*\n(https?://[^\n]+)", block)
        url = url_match.group(1).strip() if url_match else ""

        text_match = re.search(r"CLEANED_TEXT:\s*\n(.*)", block, re.DOTALL)
        text = text_match.group(1).strip() if text_match else ""

        # 过滤空文档
        if not url and not text:
            continue

        doc = {"doc_id": doc_id, "url": url, "text": text}
        samples_dict.setdefault(sample_id, []).append(doc)

    if verbose:
        print(f"解析出 {len(samples_dict)} 个样本")

    samples: List[Dict[str, Any]] = []
    for sample_id, documents in sorted(samples_dict.items(), key=lambda x: int(x[0])):
        first_doc = documents[0] if documents else {}

        if first_doc.get("url"):
            query = extract_query_from_url(first_doc["url"])
        elif first_doc.get("text"):
            query = extract_query_from_text(first_doc["text"])
        else:
            query = f"Tell me about sample {sample_id}."

        samples.append(
            {
                "sample_id": sample_id,
                "query": query,
                "documents": documents,
            }
        )

    if verbose:
        print(f"成功构建 {len(samples)} 个样本")

    return samples


if __name__ == "__main__":
    samples = load_samples()
    print(f"共加载 {len(samples)} 条样本")

    if samples:
        print("第一条预览：")
        first = samples[0]
        print(f"  sample_id: {first.get('sample_id')}")
        print(f"  query: {first.get('query')}")
        print(f"  documents数量: {len(first.get('documents', []))}")
    else:
        print("样本为空，请检查数据文件。")
