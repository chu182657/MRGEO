import re
from collections import Counter
from typing import Iterable, List, Optional, Any


def tokenize(text: Optional[str]) -> List[str]:
    """
    简单分词函数：
    - 统一小写
    - 提取英文单词、数字，以及单个中文字符
    - 返回 token 列表
    """
    if not text:
        return []
    normalized = str(text).lower()
    return re.findall(r"[a-z0-9]+|[\u4e00-\u9fff]", normalized)


def word_count(text: Optional[str]) -> int:
    """统计文本词数（基于 tokenize）。"""
    return len(tokenize(text))


def unique_word_ratio(text: Optional[str]) -> float:
    """计算唯一词占比：unique_tokens / total_tokens。"""
    tokens = tokenize(text)
    if not tokens:
        return 0.0
    return len(set(tokens)) / len(tokens)


def term_density(text: Optional[str], term_list: Optional[Iterable[str]]) -> float:
    """
    计算术语密度：术语命中次数 / 总词数。
    - token 级匹配（不区分大小写）
    - term_list 中每项先 tokenize 再参与匹配
    """
    tokens = tokenize(text)
    if not tokens or not term_list:
        return 0.0

    term_tokens = []
    for term in term_list:
        term_tokens.extend(tokenize(str(term)))

    if not term_tokens:
        return 0.0

    term_set = set(term_tokens)
    hit_count = sum(1 for tk in tokens if tk in term_set)
    return hit_count / len(tokens)


def _normalize_citation_id(c: Any) -> Optional[str]:
    """
    归一化引用ID：
    - 支持: 2, "2", "Doc2", "doc 2", "文档2", "Doc-2"
    - 统一成数字字符串 "2"（若提取不到数字则返回清洗后的原串）
    """
    s = str(c).strip().lower()
    if not s:
        return None

    # 常见格式提取数字ID
    m = re.search(r"(?:doc|文档)?\s*[-_#:]?\s*(\d+)", s)
    if m:
        return m.group(1)

    # 没数字就退化为清洗后的字符串
    s = re.sub(r"\s+", " ", s).strip()
    return s or None


def citation_rate(citations: Optional[Iterable], total_docs: int) -> float:
    """
    计算引用率：被引用文档数 / 总文档数（去重后）。
    """
    if total_docs <= 0 or not citations:
        return 0.0

    unique_cited = set()
    for c in citations:
        cid = _normalize_citation_id(c)
        if cid:
            unique_cited.add(cid)

    if not unique_cited:
        return 0.0

    # 可选：上限截断，避免异常数据 > 1.0
    return min(1.0, len(unique_cited) / float(total_docs))


def citation_frequency(citations: Optional[Iterable]) -> float:
    """
    计算引用频次（平均每个被引用文档被引用多少次）：
    total_citation_count / unique_cited_doc_count
    """
    if not citations:
        return 0.0

    normalized = []
    for c in citations:
        cid = _normalize_citation_id(c)
        if cid:
            normalized.append(cid)

    if not normalized:
        return 0.0

    counter = Counter(normalized)
    return sum(counter.values()) / len(counter)


if __name__ == "__main__":
    sample_text = "Transformer uses attention. Attention improves sequence modeling."
    sample_terms = ["transformer", "attention", "token"]
    sample_citations = [1, "Doc 2", "doc-2", "文档3", 3, "Doc#10"]

    print("word_count:", word_count(sample_text))
    print("unique_word_ratio:", round(unique_word_ratio(sample_text), 4))
    print("term_density:", round(term_density(sample_text, sample_terms), 4))
    print("citation_rate:", round(citation_rate(sample_citations, total_docs=12), 4))
    print("citation_frequency:", round(citation_frequency(sample_citations), 4))
