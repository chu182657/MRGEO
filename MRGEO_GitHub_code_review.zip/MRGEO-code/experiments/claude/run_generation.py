"""
run_generation.py
=================
批量生成回答并保存结果。

用法：
    python run_generation.py          # 全量运行（默认前200条 × METHOD_LIST）
    python run_generation.py --test   # 测试模式（前5条 × 2种方法）
"""

import argparse
import json
import logging
import time
from pathlib import Path
from typing import Dict, Any, Set, Tuple

from config import METHOD_LIST, OUTPUT_DIR
from data_loader import load_samples
from gemini_client import call_gemini
from methods import build_prompt


def setup_logger() -> logging.Logger:
    logger = logging.getLogger("run_generation")
    if logger.handlers:
        return logger

    logger.setLevel(logging.INFO)
    formatter = logging.Formatter("%(asctime)s | %(levelname)s | %(message)s")

    sh = logging.StreamHandler()
    sh.setFormatter(formatter)
    logger.addHandler(sh)

    log_dir = OUTPUT_DIR / "logs"
    log_dir.mkdir(parents=True, exist_ok=True)
    fh = logging.FileHandler(log_dir / "generation.log", encoding="utf-8")
    fh.setFormatter(formatter)
    logger.addHandler(fh)

    return logger


def load_existing_keys(output_file: Path) -> Set[Tuple[str, str]]:
    """
    读取已有结果，返回已完成的 (sample_id, method)。
    仅 success=True 且 generated_response 非空 才算已完成。
    """
    done: Set[Tuple[str, str]] = set()
    if not output_file.exists():
        return done

    with output_file.open("r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                rec = json.loads(line)
                sid = str(rec.get("sample_id", ""))
                mtd = str(rec.get("method", ""))
                ok = bool(rec.get("success", True))
                resp = str(rec.get("generated_response", "")).strip()
                if sid and mtd and ok and resp:
                    done.add((sid, mtd))
            except Exception:
                continue
    return done


def build_record(
    sample: Dict[str, Any],
    method: str,
    prompt: str,
    generated_response: str,
    success: bool = True,
    error: str = ""
) -> Dict[str, Any]:
    return {
        "sample_id": str(sample.get("sample_id", "")),
        "method": method,
        "query": str(sample.get("query", "")),
        "generated_response": generated_response,   # 与 run_evaluation 对齐
        "total_docs": len(sample.get("documents", [])) if isinstance(sample.get("documents", []), list) else 0,
        "success": success,
        "error": error,
        # 下面两项可选，但建议保留，便于追溯
        "prompt": prompt,
    }


def main():
    parser = argparse.ArgumentParser(description="GEO 批量生成脚本")
    parser.add_argument("--test", action="store_true", help="测试模式：前5条样本 + 2种方法")
    args = parser.parse_args()

    logger = setup_logger()

    logger.info("正在加载样本数据...")
    samples = load_samples()
    logger.info("共加载 %s 条样本", len(samples))

    methods = METHOD_LIST
    if args.test:
        samples = samples[:5]
        methods = ["statistics", "m2geo"]
        logger.info("【测试模式】样本=前5条，方法=statistics,m2geo")
    else:
        samples = samples[:200]
        logger.info("正式模式：限制前200条，当前样本数=%s", len(samples))

    output_dir = OUTPUT_DIR / "generations"
    output_dir.mkdir(parents=True, exist_ok=True)
    output_file = output_dir / "generation_results.jsonl"

    done_keys = load_existing_keys(output_file)
    logger.info("已完成记录 %s 条，将自动跳过", len(done_keys))

    total = len(samples) * len(methods)
    completed = 0
    skipped = 0
    failed = 0

    logger.info("开始生成，总任务=%s（%s样本 × %s方法）", total, len(samples), len(methods))

    with output_file.open("a", encoding="utf-8") as f:
        for sample in samples:
            sample_id = str(sample.get("sample_id", ""))

            for method in methods:
                key = (sample_id, method)

                if key in done_keys:
                    skipped += 1
                    continue

                try:
                    prompt = build_prompt(method, sample)
                    answer = call_gemini(prompt)
                    answer = str(answer).strip()

                    record = build_record(
                        sample=sample,
                        method=method,
                        prompt=prompt,
                        generated_response=answer,
                        success=bool(answer),
                        error="" if answer else "empty_response",
                    )

                    if answer:
                        completed += 1
                    else:
                        failed += 1

                except Exception as e:
                    failed += 1
                    record = build_record(
                        sample=sample,
                        method=method,
                        prompt="",
                        generated_response="",
                        success=False,
                        error=str(e),
                    )
                    logger.error("生成失败 sample_id=%s method=%s error=%s", sample_id, method, e)

                f.write(json.dumps(record, ensure_ascii=False) + "\n")
                f.flush()

                progress = completed + skipped + failed
                if progress % 50 == 0:
                    logger.info(
                        "进度：%s/%s（完成=%s 跳过=%s 失败=%s）",
                        progress, total, completed, skipped, failed
                    )

                time.sleep(0.5)

    logger.info("生成完成：完成=%s 跳过=%s 失败=%s", completed, skipped, failed)
    logger.info("结果文件：%s", output_file)
    print(f"\n✅ 生成完成！结果保存在：{output_file}")
    print(f"   完成：{completed} | 跳过：{skipped} | 失败：{failed}")


if __name__ == "__main__":
    main()
